
---

# IPMN: Anti-Money Laundering Detection System with Feature Engineering Library


---

## Project Overview

This project is an **enhanced anti-money laundering (AML) fraud detection system** for financial scenarios. It integrates multiple machine learning algorithms, rich feature engineering (including sliding window, graph features, temporal features, etc.), automatic data preprocessing, interactive feature selection, model training and evaluation, and visualization. The system supports both binary and multi-class classification tasks, adapts to various dataset formats, and is highly extensible and user-friendly.

**Open Source Repository:** [https://github.com/Yanuy/IPMN](https://github.com/Yanuy/IPMN)
If you have some questions, please open an issue or contact yan1@connect.hku.hk
---

## Key Features

- **Multi-dataset Support:** Automatically detects and adapts to mainstream AML datasets such as IBM and SAML formats, and supports custom CSV import.
- **Efficient Feature Engineering:**
    - Basic features, sliding window activity features, graph structure features (clustering coefficient, PageRank, betweenness centrality, cycle detection, etc.), temporal features, behavioral change features, cross-border and multi-currency features, and more.
    - Supports custom feature configurations and preset feature combinations.
- **Interactive Feature Selection:** In cache loading mode, supports command-line interactive feature selection.
- **Automatic Data Preprocessing:** Smart handling of missing values, categorical encoding, feature scaling, and prevention of data leakage.
- **Multi-model Training & Evaluation:** Integrates mainstream models such as XGBoost, supports both binary and multi-class tasks, and automatically adjusts for class imbalance.
- **Rich Visualization:** Automatically generates EDA, feature distribution, model evaluation, and other visualizations.
- **Model Persistence:** Supports saving and loading of models, encoders, and feature lists for easy deployment and reproducibility.
- **Full Pipeline Automation:** One-click execution of the entire pipeline with customizable parameters.

---

## Directory Structure

```
AML/
├── enhanced_evaluation/          # Enhanced model evaluation results
├── evaluation_plots/             # Model evaluation plots
├── models/                       # Trained models and features
├── Multi-class Classification & Feature Engineering Library.py   # Main program (recommended entry)
├── FeatureLibary.py              # Feature engineering library
├── requirements.txt              # Dependency list
├── README.md        # Multi-dataset support (Chinese)
└── ...                           # Other files
```

---

## Quick Start

### 1. Environment Setup

Python 3.8+ is recommended. Install dependencies:

```bash
pip install -r requirements.txt
```

**Main dependencies:**
- numpy, pandas, matplotlib, seaborn
- scikit-learn, xgboost, joblib
- igraph (for efficient graph feature computation)

### 2. Data Preparation

Supported datasets (place one in the project root or `data/` directory):

- `HI-Small_Trans.csv` (IBM format, binary classification)
- `SAML-D.csv` (SAML format, binary & multi-class classification)
- Cached feature files: `IBM_cache.csv`, `features_cache.csv`
- Or use your own custom CSV file

### 3. Run the Main Program

Recommended: run `IPMN.py` directly:

```bash
python IPMN.py
```

**Workflow:**

1. Automatically detects available datasets; select via command line.
2. Choose feature engineering mode (basic/full/custom).
3. Automatically loads data, performs feature engineering, splits data, trains models, evaluates, and visualizes.
4. Results and models are saved to corresponding directories.

---

## Main Functionalities

### Data Loading & Preprocessing

- Automatically detects dataset type and adapts to different field names.
- Supports chunked loading for large datasets (memory friendly).
- Smart sampling, class balancing, missing value handling, categorical encoding, and feature scaling.

### Feature Engineering

- **Basic Features:** Amount, binning, cross-border, self-transfer, currency mismatch, etc.
- **Sliding Window Features:** Account activity, frequency, amount statistics, degree features.
- **Advanced Graph Features:** Clustering coefficient, PageRank, betweenness centrality, 2/3-cycle detection (efficiently implemented with `igraph`).
- **Temporal Features:** Hour, weekday, month, periodicity, holidays, etc.
- **Behavioral Change Features:** Amount/frequency change rate, new relationship markers, etc.
- **Multi-currency/Cross-border Features:** Currency pairs, path encoding, high-risk region markers, etc.
- **Risk Score Features:** Customizable rule-based risk scoring.

### Interactive Feature Selection

- When loading cached feature files, the command line will enter an interactive feature selection interface, supporting various selection and exclusion methods.

### Data Splitting

- Supports automatic splitting of training, validation, and test sets by month or day, preventing data leakage.

### Model Training & Evaluation

- Supports XGBoost and other mainstream models, with automatic class weight adjustment.
- Binary/multi-class tasks are automatically switched; supports multi-model comparison.
- Automatically generates confusion matrices, ROC curves, AUC, F1, precision, recall, and other metrics.
- Evaluation results and plots are saved automatically.

### Visualization

- Automatically generates EDA, target distribution, amount distribution, graph feature distribution, correlation heatmaps, etc.
- Plots are saved in `eda_plots/`, `evaluation_plots/`, `enhanced_evaluation/`, etc.

### Model Persistence

- Supports saving and loading of models, encoders, and feature lists for later prediction and deployment.

---

## Typical Usage

### One-click Full Pipeline

```python
from IPMN import FraudDetectionSystem

# Initialize system (optionally specify data path)
system = FraudDetectionSystem(data_path="SAML-D.csv")

# Run the full pipeline
system.run_full_pipeline(
    sample_ratio=1.0,                # Use all data
    force_recreate_features=False,   # Use cache if available
    feature_mode='full'              # Feature mode: 'basic'/'full'/'custom'
)
```

### Custom Feature Configuration

```python
custom_config = {
    'basic': True,
    'enhanced_activity': True,
    'advanced_graph': False,  # Disable advanced graph features
    'temporal': True,
    'transaction_pattern': True,
    'risk_score': False,
    'advanced_graph_non_window': False,
    'time_series': False,
    'behavioral_change': True,
    'currency_cross_border': True
}
system.set_feature_config(custom_config)
system.run_full_pipeline(feature_mode='custom')
```

### Interactive Feature Selection

- When loading cached feature files, the command line will automatically enter the feature selection interface, supporting flexible selection and exclusion.

---

## Output

- **Models & Features:** Trained models, encoders, and feature lists are saved in the `models/` directory.
- **EDA & Evaluation Plots:** Various analysis plots are saved in `eda_plots/`, `evaluation_plots/`, `enhanced_evaluation/`, etc.
- **Detailed Evaluation Reports:** See `enhanced_evaluation/evaluation_report.md` and related files.

---

## Dependencies & Environment

- Python 3.8+
- Main dependencies in `requirements.txt`
- Graph features require `python-igraph`. If you encounter installation issues, refer to the [official documentation](https://igraph.org/python/).

---

## FAQ

1. **Dataset not detected?**
    - Ensure the data file is in the project root or `data/` directory, or manually input the full path.
2. **Feature engineering/model training is slow?**
    - Choose `basic` mode or customize to disable advanced graph features.
3. **Out of memory?**
    - The system supports chunked loading and sliding windows; running on a machine with more memory is recommended.
4. **Graph feature errors?**
    - Make sure `python-igraph` is installed correctly.



## License

This project is open-sourced under the MIT License.



**Project Homepage:** [https://github.com/Yanuy/IPMN](https://github.com/Yanuy/IPMN)

---

If you have some questions, please open an issue or contact yan1@connect.hku.hk