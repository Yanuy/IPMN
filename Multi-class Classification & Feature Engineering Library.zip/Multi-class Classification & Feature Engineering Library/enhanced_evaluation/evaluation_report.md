# 洗钱检测模型评估报告（增强版）
生成时间: 2025-07-18 16:04:14.194308

## 数据集概况
- 测试集样本数: 3168776
- 洗钱样本数: 3506
- 正常样本数: -3172282
- 洗钱类型数: 28

## 二分类模型性能
### XGBoost
- 准确率: 0.99916845
- AUC: 0.99923299

## 多分类模型性能
### XGBoost_Multi
- 多分类准确率: 0.99083589
- 欺诈检测准确率: 0.99987756
- 欺诈检测AUC: 0.99913879
- 分类类别: Behavioural_Change_1, Behavioural_Change_2, Bipartite, Cash_Withdrawal, Cycle, Deposit-Send, Fan_In, Fan_Out, Gather-Scatter, Layered_Fan_In, Layered_Fan_Out, Normal_Cash_Deposits, Normal_Cash_Withdrawal, Normal_Fan_In, Normal_Fan_Out, Normal_Foward, Normal_Group, Normal_Mutual, Normal_Periodical, Normal_Plus_Mutual, Normal_Small_Fan_Out, Normal_single_large, Over-Invoicing, Scatter-Gather, Single_large, Smurfing, Stacked Bipartite, Structuring

## 增强功能
本次评估包含以下增强功能：
1. 详细的混淆矩阵分析（原始计数和归一化）
2. 每个分类的精确度、召回率、F1分数分析
3. 多分类ROC曲线和AUC分析
4. 预测概率分布分析
5. 分类错误模式分析
6. 详细的分类报告

## 文件说明
- `*_detailed_confusion_matrix.png`: 详细混淆矩阵
- `*_class_performance.png/csv`: 各类别性能分析
- `*_multiclass_roc.png`: 多分类ROC曲线
- `*_prediction_distribution.png`: 预测概率分布
- `*_common_errors.png`: 常见分类错误
- `*_classification_report.csv`: 详细分类报告
