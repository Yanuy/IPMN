import re

import matplotlib
import numpy as np
import seaborn as sns
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    confusion_matrix, classification_report, roc_curve, auc,
    precision_recall_curve, average_precision_score,
    precision_score, recall_score, f1_score, roc_auc_score, accuracy_score,
)
from sklearn.utils.class_weight import compute_class_weight
import xgboost as xgb
import joblib
from typing import Dict
import json
import multiprocessing as mp
# 设置pandas多线程
import os
os.environ['NUMEXPR_MAX_THREADS'] = str(mp.cpu_count())
from sklearn.preprocessing import LabelEncoder
from datetime import timedelta
import os
import pandas as pd
import igraph as ig

class FraudDetectionSystem:
    """
    增强的金融欺诈检测系统
    支持多种算法，处理不平衡数据，生成图特征和时序特征
    整合了高效的滑动窗口算法，包含出度入度特征
    """

    def __init__(self, data_path: str = None, feature_cache_path: str = None):
        self.data_path = data_path
        self.df = None
        self.train_df = None
        self.test_df = None
        self.feature_columns = []
        self.encoders = {}
        self.scalers = {}
        self.models = {}
        
        # 数据集类型和缓存路径
        self.dataset_type = None
        self.feature_cache_path = feature_cache_path
        self.supports_multiclass = True  # 默认支持多分类
        
        # 自动检测数据集类型和设置缓存路径
        self._detect_dataset_type()

        # 滑动窗口参数
        self.window_days = 30  # 默认30天窗口
        self.step_days = 1  # 默认7天步长

        # 配置参数
        self.train_ratio = 0.7
        self.sample_ratio = 1.0
        
        # 特征工程配置
        self.feature_config = {
            'basic': True,                    # 基础特征
            'enhanced_activity': True,        # 增强活动特征（滑动窗口）
            'advanced_graph': True,           # 高级图特征（包含在滑动窗口中）
            'temporal': True,                 # 时间模式特征
            'transaction_pattern': True,      # 交易模式特征
            'risk_score': True,              # 风险评分特征
            'advanced_graph_non_window': True, # 非滑动窗口的高级图特征
            'time_series': True,             # 时间序列特征
            'behavioral_change': True,       # 行为变化特征
            'currency_cross_border': True    # 多币种和跨境特征
        }

        # 可视化参数
        self.feature_names = None
        # 可视化中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        # SAML可视化正常类和欺诈类
        self.normal_classes = list(range(11, 22))  # 11-21是正常类型
        self.fraud_classes = list(range(0, 11)) + list(range(22, 28))  # 其他是欺诈类型

    def _detect_dataset_type(self):
        """
        检测数据集类型并设置相应的缓存路径和任务模式
        """
        # 检测可用的数据集和缓存文件
        available_files = []
        
        # 检测原始数据集
        if os.path.exists("HI-Small_Trans.csv"):
            available_files.append(("HI-Small_Trans.csv", "IBM", "IBM_cache.csv"))
        if os.path.exists("SAML-D.csv"):
            available_files.append(("SAML-D.csv", "SAML", "features_cache.csv"))
        
        # 检测缓存文件
        if os.path.exists("IBM_cache.csv"):
            available_files.append(("IBM_cache.csv", "IBM_cached", "IBM_cache.csv"))
        if os.path.exists("features_cache.csv"):
            available_files.append(("features_cache.csv", "SAML_cached", "features_cache.csv"))
        if os.path.exists("BM_cache.csv"):
            available_files.append(("BM_cache.csv", "BM_cached", "BM_cache.csv"))
        
        # 如果用户指定了数据路径，使用指定的
        if self.data_path:
            if os.path.exists(self.data_path):
                if "HI-Small_Trans" in self.data_path:
                    self.dataset_type = "IBM"
                    self.supports_multiclass = False
                    if not self.feature_cache_path:
                        self.feature_cache_path = "IBM_cache.csv"
                elif "SAML-D" in self.data_path:
                    self.dataset_type = "SAML"
                    self.supports_multiclass = True
                    if not self.feature_cache_path:
                        self.feature_cache_path = "features_cache.csv"
                elif "cache" in self.data_path:
                    if "IBM" in self.data_path:
                        self.dataset_type = "IBM_cached"
                        self.supports_multiclass = False
                    else:
                        self.dataset_type = "SAML_cached"
                        self.supports_multiclass = True
                    self.feature_cache_path = self.data_path
                else:
                    # 其他CSV文件，默认处理方式
                    self.dataset_type = "OTHER"
                    self.supports_multiclass = True
                    if not self.feature_cache_path:
                        self.feature_cache_path = "features_cache.csv"
            else:
                print(f"Warning: Specified data path {self.data_path} does not exist")
        else:
            # 自动选择最佳数据集（优先选择缓存文件）
            cache_files = [f for f in available_files if "cached" in f[1]]
            if cache_files:
                # 优先使用缓存文件
                self.data_path, self.dataset_type, self.feature_cache_path = cache_files[0]
                self.supports_multiclass = "IBM" not in self.dataset_type
            elif available_files:
                # 使用原始数据集
                self.data_path, self.dataset_type, self.feature_cache_path = available_files[0]
                self.supports_multiclass = self.dataset_type != "IBM"
            else:
                # 没有找到任何数据集
                print("Warning: No dataset found. Please provide data_path.")
                self.dataset_type = "UNKNOWN"
                self.supports_multiclass = True
                self.feature_cache_path = "features_cache.csv"
                return
        
        print(f"Dataset type detected: {self.dataset_type}")
        print(f"Data path: {self.data_path}")
        print(f"Cache path: {self.feature_cache_path}")
        print(f"Supports multiclass: {self.supports_multiclass}")

    def _get_target_col_name(self) -> str:
        """根据数据集类型获取目标列名"""
        if self.dataset_type == "IBM":
            # 兼容处理 'Is Laundering' 和 'Is_laundering'
            if 'Is Laundering' in self.df.columns:
                return 'Is Laundering'
            return 'Is_laundering'
        else:
            return 'Is_laundering'

    def _identify_columns(self):
        """从DataFrame中识别初始的特征列、非特征列和目标变量"""
        target_col = self._get_target_col_name()
        if target_col in self.df.columns:
            self.y = self.df[target_col]
        else:
            self.y = None
            print(f"警告: 目标列 '{target_col}' 未找到。")

        # 定义明确的非特征列（包括所有可能的目标列）
        self.non_feature_cols = [
            'Sender_account', 'Receiver_account', 'Date', 'Time', 'Timestamp',
            'Amount', 'Payment_currency', 'Received_currency',
            'Sender_bank_location', 'Receiver_bank_location',
            'Transaction_type', 'Month', 'Hour',
            'Is_laundering', 'Laundering_type', 'Is Laundering'  # 明确排除所有目标列
        ]

        # 初始特征列是所有列中排除了非特征列的部分
        self.feature_columns = [col for col in self.df.columns if col not in self.non_feature_cols]

    def _get_multiline_input(self, prompt: str) -> str:
        """
        从用户处获取可能为多行的输入。
        通过提示用户输入空行来结束输入过程。
        """
        print(prompt)
        lines = []
        while True:
            try:
                line = input()
                if line:
                    lines.append(line)
                else:
                    break
            except EOFError:  # 在某些终端/IDE中，Ctrl+D (Unix) 或 Ctrl+Z (Windows) 会触发EOFError
                break
        return "\n".join(lines)

    def _get_multiline_input(self, prompt: str) -> str:
        """
        从用户处获取可能为多行的输入。
        通过提示用户输入空行来结束输入过程。
        """
        print(prompt)
        lines = []
        while True:
            try:
                line = input()
                if line:
                    lines.append(line)
                else:
                    break
            except EOFError:
                break
        return "\n".join(lines)

    def _interactive_feature_selection(self, available_features: list) -> list:
        """
        通过控制台交互式地选择特征。
        此函数接收所有可用的特征列表，并返回用户最终选择的特征列表。
        """
        current_features = available_features[:]
        available_features_set = set(available_features)

        while True:
            print("\n--- 特征管理与选择 (缓存加载模式) ---")
            print(f"当前已选择 {len(current_features)} / {len(available_features)} 个特征。")
            print("1. 完成选择 (使用当前特征并继续)")
            print("2. 显示所有可用特征的名称")
            print("3. 保留前14列特征 + 额外指定的特征")
            print("4. 保留前N列特征 + 额外指定的特征")
            print("5. 仅保留指定的特征")
            print("6. 从当前选择中排除指定的特征")
            print("7. 仅保留前N列特征")
            print("---------------------------------")

            choice = input("请输入选项 (1-7): ")

            if choice == '1':
                print("\n确认选择：将使用当前选定的特征进行建模。")
                break

            elif choice == '2':
                print("\n--- 所有可用的特征名称 ---")
                with pd.option_context('display.max_rows', None):
                    numeric_features = self.df[current_features].select_dtypes(include=np.number).columns.tolist()
                    categorical_features = self.df[current_features].select_dtypes(exclude=np.number).columns.tolist()
                    print(f"\n数值特征 ({len(numeric_features)}):\n{numeric_features}")
                    print(f"\n字符/类别特征 ({len(categorical_features)}):\n{categorical_features}")
                # 显示完后继续循环
                continue

            elif choice in ['3', '4', '5', '6', '7']:
                user_input = ""
                n = 0
                prompt_message = ""

                if choice == '3':
                    n = 14
                    prompt_message = "请输入要额外保留的特征 (可粘贴多行，以空行结束):\n"
                elif choice == '4':
                    try:
                        n_input = input("请输入要保留的前N列的 N 值: ")
                        if not n_input.strip():
                            print("未输入N值，操作取消。")
                            continue
                        n = int(n_input)
                    except ValueError:
                        print("错误：请输入一个有效的整数。")
                        continue
                    prompt_message = "请输入要额外保留的特征 (可粘贴多行，以空行结束):\n"
                elif choice == '5':
                    prompt_message = "请输入仅要保留的特征 (可粘贴多行，以空行结束):\n"
                elif choice == '6':
                    prompt_message = "请输入要排除的特征 (可粘贴多行，以空行结束):\n"
                elif choice == '7':
                    try:
                        n_input = input("请输入要保留的前N列的 N 值: ")
                        if not n_input.strip():
                            print("未输入N值，操作取消。")
                            continue
                        n = int(n_input)
                    except ValueError:
                        print("错误：请输入一个有效的整数。")
                        continue

                if prompt_message:
                    user_input = self._get_multiline_input(prompt_message)

                all_tokens = re.split(r'[\s,]+', user_input)
                input_features = sorted(
                    list({token.strip() for token in all_tokens if token.strip() in available_features_set}))

                # 更新特征列表
                if choice == '3' or choice == '4':
                    base_features = available_features[:n]
                    current_features = sorted(list(set(base_features + input_features)))
                elif choice == '5':
                    current_features = sorted([f for f in input_features if f in available_features])
                elif choice == '6':
                    exclude_set = set(input_features)
                    current_features = [f for f in current_features if f not in exclude_set]
                elif choice == '7':
                    current_features = available_features[:n]

                print(f"\n操作完成。当前已选择 {len(current_features)} 个特征。")

                # *** 新增的确认步骤 ***
                confirm_choice = input("是否完成特征选择并继续下一步？(Y/n): ").strip().lower()
                if confirm_choice == 'y' or confirm_choice == '':  # 如果用户输入'y'或直接回车
                    print("\n确认选择：将使用当前选定的特征进行建模。")
                    break  # 退出循环
                # 如果输入其他任何内容 (如 'n')，则继续循环

            else:
                print("无效选项，请输入1到7之间的数字。")

        return current_features

    def load_data(self, sample_ratio: float = 1.0, chunk_size: int = 10000,
                  force_recreate_features: bool = False, feature_mode: str = 'full') -> pd.DataFrame:
        """
        优化的数据加载函数。
        - 如果缓存存在，则加载缓存并立即进行交互式特征选择。
        - 否则，从原始数据创建特征并缓存。
        """
        self.sample_ratio = sample_ratio

        if os.path.exists(self.feature_cache_path) and not force_recreate_features:
            print(f"从缓存加载完整数据集: {self.feature_cache_path}")
            try:
                # 使用分块加载以优化内存
                chunks = [chunk for chunk in
                          pd.read_csv(self.feature_cache_path, chunksize=chunk_size, low_memory=False)]
                self.df = pd.concat(chunks, ignore_index=True)
                print(f"成功从缓存加载了 {len(self.df)} 行, {len(self.df.columns)} 列的数据。")

                # 识别所有列的类型（特征、非特征、目标）
                self._identify_columns()

                # --- 在这里进行交互式特征选择 ---
                final_selected_features = self._interactive_feature_selection(self.feature_columns)

                # 更新类的特征列表
                self.feature_columns = final_selected_features
                print(f"\n特征选择最终完成。模型将使用 {len(self.feature_columns)} 个特征。")

                # 根据选择筛选DataFrame，保留必要列和选定的特征列
                cols_to_keep = [col for col in self.non_feature_cols if col in self.df.columns] + self.feature_columns
                self.df = self.df[cols_to_keep]

                print(f"DataFrame已被筛选，当前形状: {self.df.shape}")

                self._preprocess_data()
                return self.df

            except Exception as e:
                print(f"加载缓存失败: {e}")
                import traceback
                print(traceback.format_exc())
                print("将从原始数据重新加载...")
        # 如果缓存加载失败，从原始数据加载
        print(f"Loading data from {self.data_path}...")
        try:
            if sample_ratio < 1.0:
                # 读取全部数据
                self.df = pd.read_csv(self.data_path)

                # 根据数据集类型处理采样
                if self.dataset_type == "IBM":
                    # 对HI-Small_Trans.csv，目标列是Is Laundering
                    target_col = 'Is Laundering'
                    if target_col not in self.df.columns:
                        target_col = 'Is_laundering'  # 兼容处理
                else:
                    # 对SAML-D.csv，目标列是Is_laundering
                    target_col = 'Is_laundering'

                if target_col in self.df.columns:
                    laundering_df = self.df[self.df[target_col] == 1]
                    non_laundering_df = self.df[self.df[target_col] != 1]

                    # 对非洗钱记录进行抽样
                    sampled_indices = np.random.choice(
                        non_laundering_df.index,
                        size=int(sample_ratio * len(non_laundering_df)),
                        replace=False
                    )
                    sampled_non_laundering = non_laundering_df.loc[sampled_indices]

                    # 合并并按原索引排序以保持原始顺序
                    self.df = pd.concat([laundering_df, sampled_non_laundering]).sort_index()
                else:
                    # 如果没有目标列，直接采样
                    sampled_indices = np.random.choice(
                        self.df.index,
                        size=int(sample_ratio * len(self.df)),
                        replace=False
                    )
                    self.df = self.df.loc[sampled_indices]
            else:
                # 分块加载
                chunks = []
                for chunk in pd.read_csv(self.data_path, chunksize=chunk_size):
                    chunks.append(chunk)
                self.df = pd.concat(chunks, ignore_index=True)

            print(f"Loaded {len(self.df)} transactions")
            print(f"Data shape: {self.df.shape}")

            # 数据格式转换（针对不同数据集）
            self._convert_data_format()

            # 数据预处理
            self._preprocess_data()

            # 创建特征
            print("Creating features for the loaded dataset...")
            self._create_all_features(feature_mode=feature_mode)

            # 缓存完整数据集
            self._cache_complete_dataset()

            return self.df

        except Exception as e:
            print(f"Error loading data: {e}")
            return self.df

    def _cache_complete_dataset(self):
        """
        缓存完整数据集到CSV文件
        """
        try:
            print(f"Caching complete dataset to {self.feature_cache_path}...")

            # 将float64转换为float32以减少文件大小
            df_to_save = self.df.copy()

            # 降低数值精度
            for col in df_to_save.columns:
                if df_to_save[col].dtype == 'float64':
                    df_to_save[col] = df_to_save[col].astype('float32')

            # 保存为CSV，限制小数位数以减少文件大小
            df_to_save.to_csv(
                self.feature_cache_path,
                index=False,
                float_format='%.5f'  # 限制小数位数
            )

            # 释放内存
            del df_to_save
            import gc
            gc.collect()

            print(f"Complete dataset cached to {self.feature_cache_path}")

        except Exception as e:
            print(f"Error caching dataset: {e}")
            import traceback
            print(traceback.format_exc())

    def _convert_data_format(self):
        """
        根据数据集类型转换数据格式
        """
        if self.dataset_type == "IBM":
            # HI-Small_Trans.csv格式转换
            print("Converting HI-Small_Trans.csv format...")
            
            # 列名映射
            column_mapping = {
                'Timestamp': 'Timestamp',
                'From Bank': 'Sender_bank_location',
                'To Bank': 'Receiver_bank_location',
                'Amount Received': 'Amount',
                'Receiving Currency': 'Received_currency',
                'Payment Currency': 'Payment_currency',
                'Payment Format': 'Payment_type',
                'Is Laundering': 'Is_laundering'
            }
            
            # 处理Account列（有两个Account列）
            # pandas在读取时会自动处理重复列名，通常第二个会变成Account.1
            if 'Account' in self.df.columns:
                self.df['Sender_account'] = self.df['Account']
                self.df = self.df.drop(columns=['Account'])
            
            if 'Account.1' in self.df.columns:
                self.df['Receiver_account'] = self.df['Account.1']
                self.df = self.df.drop(columns=['Account.1'])
            
            # 如果没有找到Account.1，尝试其他可能的命名
            account_cols = [col for col in self.df.columns if col.startswith('Account')]
            if len(account_cols) >= 2:
                # 按列顺序处理
                self.df['Sender_account'] = self.df[account_cols[0]]
                self.df['Receiver_account'] = self.df[account_cols[1]]
                self.df = self.df.drop(columns=account_cols)
            
            # 重命名其他列
            for old_name, new_name in column_mapping.items():
                if old_name in self.df.columns:
                    self.df = self.df.rename(columns={old_name: new_name})
            
            # 处理时间戳（拆分为日期和时间）
            if 'Timestamp' in self.df.columns:
                # 解析时间戳
                timestamp_series = pd.to_datetime(self.df['Timestamp'], errors='coerce')
                self.df['Date'] = timestamp_series.dt.date
                self.df['Time'] = timestamp_series.dt.time.astype(str)
                # 删除原时间戳列
                self.df = self.df.drop(columns=['Timestamp'])
            
            # 为兼容性添加缺失的列
            if 'Laundering_type' not in self.df.columns:
                # 对于HI-Small_Trans.csv，没有多分类信息
                self.df['Laundering_type'] = 'Unknown'
            
            # 处理可能的缺失列
            required_cols = ['Sender_account', 'Receiver_account', 'Date', 'Time', 'Amount', 
                           'Payment_currency', 'Received_currency', 'Sender_bank_location', 
                           'Receiver_bank_location', 'Payment_type', 'Is_laundering']
            
            for col in required_cols:
                if col not in self.df.columns:
                    if col in ['Sender_account', 'Receiver_account']:
                        self.df[col] = 'Unknown'
                    elif col == 'Payment_type':
                        self.df[col] = 'Unknown'
                    elif col in ['Payment_currency', 'Received_currency']:
                        self.df[col] = 'USD'
                    elif col in ['Sender_bank_location', 'Receiver_bank_location']:
                        self.df[col] = 'Unknown'
                    else:
                        self.df[col] = 0
            
            print(f"Converted to standard format. Columns: {list(self.df.columns)}")
            
        elif self.dataset_type in ["SAML", "OTHER"]:
            # SAML-D.csv或其他格式，保持原样
            print("Using original SAML-D format...")
            pass
        
        else:
            # 缓存文件，已经是标准格式
            print("Using cached format...")
            pass

    def _preprocess_data(self):
        """数据预处理"""
        print("Preprocessing data...")

        # 转换日期时间
        if 'Date' in self.df.columns:
            self.df['Date'] = pd.to_datetime(self.df['Date'], errors='coerce')

        # 处理时间字段
        if 'Time' in self.df.columns:
            self.df['Hour'] = pd.to_datetime(self.df['Time'], format='%H:%M:%S', errors='coerce').dt.hour
            # 新增：提取分钟和秒，用于更细粒度的时间分析
            self.df['Minute'] = pd.to_datetime(self.df['Time'], format='%H:%M:%S', errors='coerce').dt.minute
            self.df['Second'] = pd.to_datetime(self.df['Time'], format='%H:%M:%S', errors='coerce').dt.second

        # 添加月份信息用于划分数据集
        self.df['Month'] = self.df['Date'].dt.to_period('M')

        # 排序
        # self.df = self.df.sort_values(['Date', 'Time']).reset_index(drop=True)

        print(f"Date range: {self.df['Date'].min()} to {self.df['Date'].max()}")
        print(f"Fraud rate: {self.df['Is_laundering'].mean():.8f}")
    ###数据集划分部分
    def split_data_by_month(self, train_ratio: float = 0.7, validation_ratio: float = 0):
        """按月份或天数划分训练集、验证集和测试集"""
        print(f"Splitting data with train ratio: {train_ratio}, validation ratio: {validation_ratio}")

        # 确保比例合理
        if train_ratio + validation_ratio >= 1.0:
            raise ValueError("训练集和验证集比例之和必须小于1.0")

        self.train_ratio = train_ratio
        self.validation_ratio = validation_ratio

        # 检查是否有Month字段，以及月份数量是否足够
        if 'Month' in self.df.columns and len(self.df['Month'].unique()) > 3:
            # 按月份划分
            return self._split_by_month(train_ratio, validation_ratio)
        else:
            # 按天数划分
            return self._split_by_day(train_ratio, validation_ratio)

    def _split_by_month(self, train_ratio, validation_ratio):
        """基于月份划分数据"""
        unique_months = sorted(self.df['Month'].unique())

        # 计算每个集合的月份数
        train_months_count = int(len(unique_months) * train_ratio)
        validation_months_count = int(len(unique_months) * validation_ratio)

        # 分配月份
        train_months = unique_months[:train_months_count]
        validation_months = unique_months[train_months_count:train_months_count + validation_months_count]
        test_months = unique_months[train_months_count + validation_months_count:]

        # 确保我们有足够的数据用于测试
        if not test_months:
            raise ValueError("没有足够的月份用于测试集划分")

        # 创建训练集
        self.train_df = self.df[self.df['Month'].isin(train_months)].copy()

        # 创建验证集（从第一个验证月份开始的7天后）
        if validation_months:
            first_validation_month = validation_months[0]
            validation_start_date = pd.to_datetime(str(first_validation_month)) + timedelta(days=7)
            validation_mask = (self.df['Month'].isin(validation_months)) & (self.df['Date'] >= validation_start_date)
            self.validation_df = self.df[validation_mask].copy()
        else:
            self.validation_df = None

        # 创建测试集（从第一个测试月份开始的7天后）
        first_test_month = test_months[0]
        test_start_date = pd.to_datetime(str(first_test_month)) + timedelta(days=7)
        test_mask = (self.df['Month'].isin(test_months)) & (self.df['Date'] >= test_start_date)
        self.test_df = self.df[test_mask].copy()

        # 打印分割信息
        print(f"按月份划分数据:")
        print(f"训练月份: {len(train_months)} ({train_months[0]} 到 {train_months[-1]})")
        if validation_months:
            print(f"验证月份: {len(validation_months)} ({validation_months[0]} 到 {validation_months[-1]})")
        print(f"测试月份: {len(test_months)} ({test_months[0]} 到 {test_months[-1]})")

        self._print_split_stats()
        self._handle_categorical_features()

        return self.train_df, self.validation_df, self.test_df

    def _split_by_day(self, train_ratio, validation_ratio):
        """基于天数划分数据"""
        # 确保Date字段已转换为datetime类型
        if 'Date' not in self.df.columns:
            raise ValueError("数据集中没有'Date'字段，无法按天数划分")

        # 排序日期
        sorted_dates = sorted(self.df['Date'].unique())

        # 计算每个集合的天数
        total_days = len(sorted_dates)
        train_days_count = int(total_days * train_ratio)
        validation_days_count = int(total_days * validation_ratio)

        # 分配日期
        train_dates = sorted_dates[:train_days_count]
        validation_dates = sorted_dates[train_days_count:train_days_count + validation_days_count]
        test_dates = sorted_dates[train_days_count + validation_days_count:]

        # 确保我们有足够的数据用于测试
        if not test_dates:
            raise ValueError("没有足够的天数用于测试集划分")

        # 创建训练集
        self.train_df = self.df[self.df['Date'].isin(train_dates)].copy()

        # 创建验证集
        if validation_dates:
            self.validation_df = self.df[self.df['Date'].isin(validation_dates)].copy()
        else:
            self.validation_df = None

        # 创建测试集
        self.test_df = self.df[self.df['Date'].isin(test_dates)].copy()

        # 打印分割信息
        print(f"按天数划分数据:")
        print(
            f"训练天数: {len(train_dates)} ({train_dates[0].strftime('%Y-%m-%d')} 到 {train_dates[-1].strftime('%Y-%m-%d')})")
        if validation_dates:
            print(
                f"验证天数: {len(validation_dates)} ({validation_dates[0].strftime('%Y-%m-%d')} 到 {validation_dates[-1].strftime('%Y-%m-%d')})")
        print(
            f"测试天数: {len(test_dates)} ({test_dates[0].strftime('%Y-%m-%d')} 到 {test_dates[-1].strftime('%Y-%m-%d')})")

        self._print_split_stats()
        self._handle_categorical_features()

        return self.train_df, self.validation_df, self.test_df

    def _print_split_stats(self):
        """打印分割统计信息"""
        print(f"训练样本数: {len(self.train_df)}")
        if self.validation_df is not None:
            print(f"验证样本数: {len(self.validation_df)}")
        print(f"测试样本数: {len(self.test_df)}")
        print(f"训练集洗钱率: {self.train_df['Is_laundering'].mean():.8f}")
        if self.validation_df is not None:
            print(f"验证集洗钱率: {self.validation_df['Is_laundering'].mean():.8f}")
        print(f"测试集洗钱率: {self.test_df['Is_laundering'].mean():.8f}")
    ###
    def _handle_categorical_features(self):
        """确保训练集、验证集和测试集中的分类变量有相同的类别"""
        categorical_columns = self.train_df.select_dtypes(include=['category']).columns

        for col in categorical_columns:
            # 收集所有数据集中的类别
            all_categories = set(self.train_df[col].cat.categories)

            if hasattr(self, 'validation_df') and self.validation_df is not None:
                all_categories.update(self.validation_df[col].cat.categories)

            if hasattr(self, 'test_df') and self.test_df is not None:
                all_categories.update(self.test_df[col].cat.categories)

            # 确保'unknown'在类别中
            all_categories.add('unknown')
            all_categories = list(all_categories)

            # 更新所有数据集的类别
            self.train_df[col] = self.train_df[col].cat.set_categories(all_categories)

            if hasattr(self, 'validation_df') and self.validation_df is not None:
                self.validation_df[col] = self.validation_df[col].cat.set_categories(all_categories)

            if hasattr(self, 'test_df') and self.test_df is not None:
                self.test_df[col] = self.test_df[col].cat.set_categories(all_categories)

    def _create_all_features(self, feature_mode: str = 'full'):
        """
        创建所有特征
        
        Parameters:
        feature_mode: str
            - 'basic': 仅创建基础特征，不包含高级图特征
            - 'full': 创建所有特征（默认）
            - 'custom': 根据 self.feature_config 配置创建特征
        """
        try:
            # 根据模式设置特征配置
            if feature_mode == 'basic':
                # 基础模式：不包含高级图特征
                config = {
                    'basic': True,
                    'enhanced_activity': True,  # 滑动窗口特征，但不包含高级图
                    'advanced_graph': False,    # 关闭滑动窗口中的高级图特征
                    'temporal': True,
                    'transaction_pattern': True,
                    'risk_score': True,
                    'advanced_graph_non_window': False,  # 关闭非滑动窗口的高级图特征
                    'time_series': True,
                    'behavioral_change': True,
                    'currency_cross_border': True
                }
            elif feature_mode == 'full':
                # 全量模式：创建所有特征
                config = {
                    'basic': True,
                    'enhanced_activity': True,
                    'advanced_graph': True,
                    'temporal': True,
                    'transaction_pattern': True,
                    'risk_score': True,
                    'advanced_graph_non_window': True,
                    'time_series': True,
                    'behavioral_change': True,
                    'currency_cross_border': True
                }
            elif feature_mode == 'custom':
                # 自定义模式：使用实例的配置
                config = self.feature_config.copy()
            else:
                print(f"Warning: Unknown feature_mode '{feature_mode}', using 'full' mode")
                config = {
                    'basic': True,
                    'enhanced_activity': True,
                    'advanced_graph': True,
                    'temporal': True,
                    'transaction_pattern': True,
                    'risk_score': True,
                    'advanced_graph_non_window': True,
                    'time_series': True,
                    'behavioral_change': True,
                    'currency_cross_border': True
                }
            
            print(f"Feature creation mode: {feature_mode}")
            print(f"Feature configuration: {config}")
            
            # 基础特征
            if config.get('basic', False):
                print("Creating basic features...")
                self._create_basic_features()

            # 使用高效滑动窗口算法创建活动特征（包含出度入度）
            if config.get('enhanced_activity', False):
                print("Creating enhanced activity features...")
                # 传递高级图特征的开关给滑动窗口
                self._create_enhanced_activity_features(enable_advanced_graph=config.get('advanced_graph', False))

            # 时间模式特征
            if config.get('temporal', False):
                print("Creating temporal features...")
                self._create_temporal_features()

            # 交易模式特征
            if config.get('transaction_pattern', False):
                print("Creating transaction pattern features...")
                self._create_transaction_pattern_features()

            # 风险评分特征
            if config.get('risk_score', False):
                print("Creating risk score features...")
                self._create_risk_score_features()

            # 新增：增强的图特征（非滑动窗口）
            if config.get('advanced_graph_non_window', False):
                print("Creating advanced graph features (non-window)...")
                self._create_advanced_graph_features()

            # 新增：时间序列特征
            if config.get('time_series', False):
                print("Creating time series features...")
                self._create_time_series_features()

            # 新增：行为变化特征
            if config.get('behavioral_change', False):
                print("Creating behavioral change features...")
                self._create_behavioral_change_features()

            # 新增：多币种和跨境增强特征
            if config.get('currency_cross_border', False):
                print("Creating currency and cross-border features...")
                self._create_currency_and_cross_border_features()

            print("Feature creation completed successfully")

        except Exception as e:
            print(f"Error in feature creation: {e}")
            import traceback
            traceback.print_exc()

    def _create_basic_features(self):
        """创建基础特征"""
        print("Creating basic features...")

        # 金额特征
        self.df['Amount_log'] = np.log1p(self.df['Amount'])
        self.df['Amount_sqrt'] = np.sqrt(self.df['Amount'])
        # 金额分箱特征
        self.df['Amount_bin'] = pd.cut(self.df['Amount'],
                                       bins=[0, 0.1, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000,
                                             float('inf')],
                                       labels=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        # 整数金额标记
        self.df['Is_round_amount'] = (self.df['Amount'] % 1 == 0).astype(int)
        self.df['Is_large_round'] = ((self.df['Amount'] % 1000 == 0) & (self.df['Amount'] >= 1000)).astype(int)

        # 新增：特殊金额模式
        self.df['Is_round_hundred'] = (self.df['Amount'] % 100 == 0).astype(int)
        self.df['Is_round_ten_thousand'] = (self.df['Amount'] % 10000 == 0).astype(int)
        self.df['Has_99_pattern'] = (self.df['Amount'] % 100 > 95).astype(int)  # 如999, 1999等

        # 跨境标记
        self.df['Is_cross_border'] = (self.df['Sender_bank_location'] != self.df['Receiver_bank_location']).astype(
            int)

        # 货币不匹配标记
        self.df['Currency_mismatch'] = (self.df['Payment_currency'] != self.df['Received_currency']).astype(int)

        # 自转账标记
        self.df['Is_self_transfer'] = (self.df['Sender_account'] == self.df['Receiver_account']).astype(int)

    def _create_enhanced_activity_features(self, enable_advanced_graph: bool = True):
        """使用高效滑动窗口算法创建增强的活动特征"""
        print("Creating enhanced activity features using sliding window...")

        # 基础特征列
        basic_feature_columns = [
            # 原有特征
            'Sender_send_amount', 'Sender_send_count', 'Sender_send_frequency',
            'Receiver_receive_amount', 'Receiver_receive_count', 'Receiver_receive_frequency',
            'Sender_receive_amount', 'Sender_receive_count', 'Sender_receive_frequency',
            'Receiver_send_amount', 'Receiver_send_count', 'Receiver_send_frequency',
            'Sender_out_degree', 'Sender_in_degree',
            'Receiver_in_degree', 'Receiver_out_degree',
            'Pair_transaction_count', 'Pair_transaction_amount',
            'Sender_total_activity_count', 'Receiver_total_activity_count',
            # 统计特征
            'Sender_amount_variance', 'Receiver_amount_variance',
            'Sender_unique_receivers', 'Receiver_unique_senders',
            'Sender_avg_amount', 'Receiver_avg_amount',
            'Sender_amount_std', 'Receiver_amount_std',
            'Pair_avg_amount', 'Pair_time_span_days'
        ]
        
        # 高级图特征列
        advanced_graph_features = [
            'Sender_clustering_coef', 'Receiver_clustering_coef',
            'Sender_pagerank', 'Receiver_pagerank',
            'Has_2_cycle', 'Has_3_cycle',
            'Sender_betweenness_centrality', 'Receiver_betweenness_centrality'
        ]
        
        # 根据设置决定创建哪些特征
        if enable_advanced_graph:
            self.feature_columns_list = basic_feature_columns + advanced_graph_features
            print("Including advanced graph features in sliding window calculation")
        else:
            self.feature_columns_list = basic_feature_columns
            print("Excluding advanced graph features from sliding window calculation")

        # 初始化特征列为 NaN
        for col in self.feature_columns_list:
            self.df[col] = np.nan

        # 调用核心滑动窗口计算逻辑
        self.df = self._window_slider(self.df, self.window_days, self.step_days, enable_advanced_graph=enable_advanced_graph)

        print("Enhanced activity features created successfully.")
        return self.df

    def _window_graph(self, window_df: pd.DataFrame, window_days_for_freq_calc: int, enable_advanced_graph: bool = True):
        """
        计算指定窗口内的 Sender、Receiver 的交易统计信息、度数特征、图特征和总活动计数。
        增强版本包含更多图论特征。
        """
        # 计算频率时使用的总天数
        total_days_for_freq = max(window_days_for_freq_calc, 1)  # 避免除零错误

        # ========== 原有统计 ==========
        # Sender 发送统计
        sender_send_stats = window_df.groupby("Sender_account").agg(
            Sender_send_amount_calc=("Amount", "sum"),
            Sender_send_count_calc=("Amount", "count"),
            Sender_amount_variance_calc=("Amount", "var"),
            Sender_avg_amount_calc=("Amount", "mean"),
            Sender_amount_std_calc=("Amount", "std")
        ).reset_index()
        sender_send_stats["Sender_send_frequency_calc"] = sender_send_stats[
                                                              "Sender_send_count_calc"] / total_days_for_freq

        # Receiver 接收统计
        receiver_receive_stats = window_df.groupby("Receiver_account").agg(
            Receiver_receive_amount_calc=("Amount", "sum"),
            Receiver_receive_count_calc=("Amount", "count"),
            Receiver_amount_variance_calc=("Amount", "var"),
            Receiver_avg_amount_calc=("Amount", "mean"),
            Receiver_amount_std_calc=("Amount", "std")
        ).reset_index()
        receiver_receive_stats["Receiver_receive_frequency_calc"] = receiver_receive_stats[
                                                                        "Receiver_receive_count_calc"] / total_days_for_freq

        # Sender 作为接收者的统计
        sender_receive_stats = window_df.groupby("Receiver_account").agg(
            Sender_receive_amount_calc=("Amount", "sum"),
            Sender_receive_count_calc=("Amount", "count")
        ).reset_index()
        sender_receive_stats.rename(columns={"Receiver_account": "Sender_account"}, inplace=True)
        sender_receive_stats["Sender_receive_frequency_calc"] = sender_receive_stats[
                                                                    "Sender_receive_count_calc"] / total_days_for_freq

        # Receiver 作为发送者的统计
        receiver_send_stats = window_df.groupby("Sender_account").agg(
            Receiver_send_amount_calc=("Amount", "sum"),
            Receiver_send_count_calc=("Amount", "count")
        ).reset_index()
        receiver_send_stats.rename(columns={"Sender_account": "Receiver_account"}, inplace=True)
        receiver_send_stats["Receiver_send_frequency_calc"] = receiver_send_stats[
                                                                  "Receiver_send_count_calc"] / total_days_for_freq

        # ========== 度数特征 ==========
        sender_out_degree = window_df.groupby("Sender_account")["Receiver_account"].nunique().reset_index()
        sender_out_degree.rename(columns={"Receiver_account": "Sender_out_degree_calc"}, inplace=True)

        receiver_in_degree = window_df.groupby("Receiver_account")["Sender_account"].nunique().reset_index()
        receiver_in_degree.rename(columns={"Sender_account": "Receiver_in_degree_calc"}, inplace=True)

        sender_in_degree = window_df.groupby("Receiver_account")["Sender_account"].nunique().reset_index()
        sender_in_degree.rename(
            columns={"Receiver_account": "Sender_account", "Sender_account": "Sender_in_degree_calc"}, inplace=True)

        receiver_out_degree = window_df.groupby("Sender_account")["Receiver_account"].nunique().reset_index()
        receiver_out_degree.rename(
            columns={"Sender_account": "Receiver_account", "Receiver_account": "Receiver_out_degree_calc"},
            inplace=True)

        # ========== 新增：唯一连接数 ==========
        sender_unique_receivers = window_df.groupby("Sender_account")["Receiver_account"].nunique().reset_index()
        sender_unique_receivers.rename(columns={"Receiver_account": "Sender_unique_receivers_calc"}, inplace=True)

        receiver_unique_senders = window_df.groupby("Receiver_account")["Sender_account"].nunique().reset_index()
        receiver_unique_senders.rename(columns={"Sender_account": "Receiver_unique_senders_calc"}, inplace=True)

        # ========== 账户对交易特征（增强版） ==========
        pair_stats = window_df.groupby(["Sender_account", "Receiver_account"]).agg(
            Pair_transaction_count_calc=("Amount", "count"),
            Pair_transaction_amount_calc=("Amount", "sum"),
            Pair_avg_amount_calc=("Amount", "mean"),
            Pair_first_date=("Date", "min"),
            Pair_last_date=("Date", "max")
        ).reset_index()
        # 计算账户对的时间跨度
        pair_stats["Pair_time_span_days_calc"] = (
                    pair_stats["Pair_last_date"] - pair_stats["Pair_first_date"]).dt.days

        # ========== 总活动计数 ==========
        outgoing_counts_in_window = window_df['Sender_account'].value_counts()
        incoming_counts_in_window = window_df['Receiver_account'].value_counts()
        total_activity_counts_series = outgoing_counts_in_window.add(incoming_counts_in_window, fill_value=0)
        total_activity_counts_df = total_activity_counts_series.reset_index()
        total_activity_counts_df.columns = ['Account', 'Total_activity_count_calc']

        # ========== 新增：高级图特征 ==========
        if enable_advanced_graph:
            graph_features = self._calculate_graph_features(window_df)
        else:
            # 创建空的图特征字典以保持一致的返回结构
            graph_features = {
                'clustering_coef': pd.DataFrame(),
                'pagerank': pd.DataFrame(),
                'betweenness_centrality': pd.DataFrame(),
                'cycles': {
                    'has_2_cycle': pd.DataFrame(),
                    'has_3_cycle': pd.DataFrame()
                }
            }

        # 返回字典，索引已设置
        return {
            "sender_send_stats": sender_send_stats.set_index("Sender_account"),
            "receiver_receive_stats": receiver_receive_stats.set_index("Receiver_account"),
            "sender_receive_stats": sender_receive_stats.set_index("Sender_account"),
            "receiver_send_stats": receiver_send_stats.set_index("Receiver_account"),
            "sender_out_degree": sender_out_degree.set_index("Sender_account"),
            "receiver_in_degree": receiver_in_degree.set_index("Receiver_account"),
            "sender_in_degree": sender_in_degree.set_index("Sender_account"),
            "receiver_out_degree": receiver_out_degree.set_index("Receiver_account"),
            "sender_unique_receivers": sender_unique_receivers.set_index("Sender_account"),
            "receiver_unique_senders": receiver_unique_senders.set_index("Receiver_account"),
            "pair_stats": pair_stats.set_index(["Sender_account", "Receiver_account"]),
            "total_activity_counts": total_activity_counts_df.set_index("Account"),
            "graph_features": graph_features
        }

    def _calculate_graph_features(self, window_df):
        """计算高级图特征 - 使用igraph代替networkx"""
        # 获取所有唯一的账户
        all_accounts = pd.concat([window_df['Sender_account'], window_df['Receiver_account']]).unique()
        account_to_idx = {acc: idx for idx, acc in enumerate(all_accounts)}
        idx_to_account = {idx: acc for acc, idx in account_to_idx.items()}

        # 准备边列表和权重
        edges = []
        weights = []
        edge_dict = {}

        for _, row in window_df.iterrows():
            src_idx = account_to_idx[row['Sender_account']]
            dst_idx = account_to_idx[row['Receiver_account']]
            edge_key = (src_idx, dst_idx)

            if edge_key in edge_dict:
                edge_dict[edge_key]['weight'] += row['Amount']
                edge_dict[edge_key]['count'] += 1
            else:
                edge_dict[edge_key] = {'weight': row['Amount'], 'count': 1}

        # 构建边列表和权重列表
        for (src, dst), attrs in edge_dict.items():
            edges.append((src, dst))
            weights.append(attrs['weight'])

        # 创建igraph有向图
        g = ig.Graph(n=len(all_accounts), edges=edges, directed=True)
        g.es['weight'] = weights

        # 计算各种图特征
        features = {}

        # 聚类系数（转换为无向图计算）
        g_undirected = g.as_undirected(mode="collapse", combine_edges="sum")
        clustering_values = g_undirected.transitivity_local_undirected(mode="zero")
        clustering_dict = {idx_to_account[i]: val for i, val in enumerate(clustering_values)}
        features['clustering_coef'] = pd.DataFrame.from_dict(clustering_dict, orient='index',
                                                             columns=['clustering_coef_calc'])

        # PageRank
        try:
            pagerank_values = g.pagerank(weights='weight')
            pagerank_dict = {idx_to_account[i]: val for i, val in enumerate(pagerank_values)}
            features['pagerank'] = pd.DataFrame.from_dict(pagerank_dict, orient='index', columns=['pagerank_calc'])
        except:
            features['pagerank'] = pd.DataFrame()

        # 介数中心性（对小图计算）
        if len(all_accounts) < 1000:  # 限制计算规模
            try:
                betweenness_values = g.betweenness(directed=True, weights='weight')
                # 归一化
                max_betweenness = max(betweenness_values) if betweenness_values else 1
                if max_betweenness > 0:
                    betweenness_values = [v / max_betweenness for v in betweenness_values]
                betweenness_dict = {idx_to_account[i]: val for i, val in enumerate(betweenness_values)}
                features['betweenness_centrality'] = pd.DataFrame.from_dict(betweenness_dict, orient='index',
                                                                            columns=['betweenness_centrality_calc'])
            except:
                features['betweenness_centrality'] = pd.DataFrame()
        else:
            features['betweenness_centrality'] = pd.DataFrame()

        # 循环检测
        features['cycles'] = self._detect_cycles_igraph(g, idx_to_account)

        return features

    def _detect_cycles_igraph(self, g, idx_to_account):
        """使用igraph检测图中的循环"""
        cycle_features = {}

        # 2-cycle检测（A->B->A）
        nodes_in_2cycle = set()

        # 检查每个节点的出邻居和入邻居
        for v in range(g.vcount()):
            out_neighbors = set(g.successors(v))
            in_neighbors = set(g.predecessors(v))

            # 检查是否存在既是出邻居又是入邻居的节点（形成2-cycle）
            mutual_neighbors = out_neighbors & in_neighbors
            if mutual_neighbors:
                nodes_in_2cycle.add(v)
                nodes_in_2cycle.update(mutual_neighbors)

        # 转换为账户名
        cycle_features['has_2_cycle'] = pd.DataFrame.from_dict(
            {idx_to_account[v]: 1 if v in nodes_in_2cycle else 0 for v in range(g.vcount())},
            orient='index', columns=['has_2_cycle_calc']
        )

        # 3-cycle检测（简化版）
        nodes_in_3cycle = set()

        # 对每个节点检查是否参与3-cycle
        for v in range(g.vcount()):
            out_neighbors = list(g.successors(v))

            # 检查v的出邻居之间是否有连接
            for i, n1 in enumerate(out_neighbors):
                for j, n2 in enumerate(out_neighbors):
                    if i != j:
                        # 检查n1->n2或n2->n1是否存在
                        if g.are_connected(n1, n2) or g.are_connected(n2, n1):
                            # 再检查是否有边回到v
                            if g.are_connected(n2, v) or g.are_connected(n1, v):
                                nodes_in_3cycle.update([v, n1, n2])

        # 转换为账户名
        cycle_features['has_3_cycle'] = pd.DataFrame.from_dict(
            {idx_to_account[v]: 1 if v in nodes_in_3cycle else 0 for v in range(g.vcount())},
            orient='index', columns=['has_3_cycle_calc']
        )

        return cycle_features

    def _window_slider(self, dataset: pd.DataFrame, window_days: int, step_days: int, enable_advanced_graph: bool = True):
        """无数据泄露的滑动窗口核心实现（增强版）"""
        print(f"Starting sliding window calculation with {window_days} days window and {step_days} days step...")

        if 'Date' not in dataset.columns or not pd.api.types.is_datetime64_any_dtype(dataset['Date']):
            print("Error: 'Date' column is missing or not in datetime format.")
            return dataset

        all_unique_dates = sorted(dataset['Date'].unique())
        if not all_unique_dates:
            print("No dates found in dataset. Exiting window slider.")
            return dataset

        min_dataset_date = all_unique_dates[0]

        # 预计算日期索引以提高性能
        date_to_idx = {date: idx for idx, date in enumerate(all_unique_dates)}

        current_target_date_idx = 0
        processed_windows = 0

        while current_target_date_idx < len(all_unique_dates):
            target_period_start_date = all_unique_dates[current_target_date_idx]
            target_period_end_date_idx = min(current_target_date_idx + step_days - 1, len(all_unique_dates) - 1)
            target_period_end_date = all_unique_dates[target_period_end_date_idx]

            # 定义历史数据计算窗口 [hist_start, hist_end]
            # 特征不滞后：目标时段T的特征，基于当天及之前的数据
            hist_window_end_date = target_period_start_date
            hist_window_start_date = hist_window_end_date - pd.Timedelta(days=window_days - 1)
            # 修改：调整历史窗口开始日期，确保不早于数据集的最小日期
            actual_hist_start_date = max(hist_window_start_date, min_dataset_date)

            # 计算实际可用的历史天数
            actual_window_days = (hist_window_end_date - actual_hist_start_date).days + 1

            # 验证时间窗口
            if not self._validate_time_window(actual_hist_start_date, hist_window_end_date,
                                              target_period_start_date):
                print(f"Warning: Time window validation failed for target {target_period_start_date.date()}")
                current_target_date_idx += step_days
                continue

            if actual_window_days < window_days:
                print(
                    f"  Target period: {target_period_start_date.date()} to {target_period_end_date.date()}. Features from: {actual_hist_start_date.date()} to {hist_window_end_date.date()} (partial window: {actual_window_days} days)")
            else:
                print(
                    f"  Target period: {target_period_start_date.date()} to {target_period_end_date.date()}. Features from: {actual_hist_start_date.date()} to {hist_window_end_date.date()} (full window: {actual_window_days} days)")

            # 使用调整后的历史窗口
            hist_data_mask = (dataset['Date'] >= actual_hist_start_date) & (dataset['Date'] <= hist_window_end_date)
            window_df_for_calc = dataset.loc[
                hist_data_mask, ['Date', 'Sender_account', 'Receiver_account', 'Amount']].copy()

            if window_df_for_calc.empty:
                print(
                    f"    Skipping target {target_period_start_date.date()}-{target_period_end_date.date()}: No data in feature calculation window.")
                current_target_date_idx += step_days
                continue

            try:
                # 使用实际的窗口天数进行频率计算
                aggregated_stats_map = self._window_graph(window_df_for_calc,
                                                          window_days_for_freq_calc=actual_window_days,
                                                          enable_advanced_graph=enable_advanced_graph)
            except Exception as e:
                print(
                    f"Error calculating features for window {actual_hist_start_date.date()}-{hist_window_end_date.date()}: {e}")
                current_target_date_idx += step_days
                continue

            target_rows_mask = (dataset['Date'] >= target_period_start_date) & (
                        dataset['Date'] <= target_period_end_date)
            target_indices = dataset[target_rows_mask].index

            if target_indices.empty:
                current_target_date_idx += step_days
                continue

            # 定义特征映射规则（包含新增特征）
            feature_mappings = [
                # 原有特征
                ('Sender_account', 'sender_send_stats', 'Sender_send_amount_calc', 'Sender_send_amount'),
                ('Sender_account', 'sender_send_stats', 'Sender_send_count_calc', 'Sender_send_count'),
                ('Sender_account', 'sender_send_stats', 'Sender_send_frequency_calc', 'Sender_send_frequency'),
                ('Sender_account', 'sender_send_stats', 'Sender_amount_variance_calc', 'Sender_amount_variance'),
                ('Sender_account', 'sender_send_stats', 'Sender_avg_amount_calc', 'Sender_avg_amount'),
                ('Sender_account', 'sender_send_stats', 'Sender_amount_std_calc', 'Sender_amount_std'),

                ('Receiver_account', 'receiver_receive_stats', 'Receiver_receive_amount_calc',
                 'Receiver_receive_amount'),
                ('Receiver_account', 'receiver_receive_stats', 'Receiver_receive_count_calc',
                 'Receiver_receive_count'),
                ('Receiver_account', 'receiver_receive_stats', 'Receiver_receive_frequency_calc',
                 'Receiver_receive_frequency'),
                ('Receiver_account', 'receiver_receive_stats', 'Receiver_amount_variance_calc',
                 'Receiver_amount_variance'),
                ('Receiver_account', 'receiver_receive_stats', 'Receiver_avg_amount_calc', 'Receiver_avg_amount'),
                ('Receiver_account', 'receiver_receive_stats', 'Receiver_amount_std_calc', 'Receiver_amount_std'),

                ('Sender_account', 'sender_receive_stats', 'Sender_receive_amount_calc', 'Sender_receive_amount'),
                ('Sender_account', 'sender_receive_stats', 'Sender_receive_count_calc', 'Sender_receive_count'),
                ('Sender_account', 'sender_receive_stats', 'Sender_receive_frequency_calc',
                 'Sender_receive_frequency'),

                ('Receiver_account', 'receiver_send_stats', 'Receiver_send_amount_calc', 'Receiver_send_amount'),
                ('Receiver_account', 'receiver_send_stats', 'Receiver_send_count_calc', 'Receiver_send_count'),
                ('Receiver_account', 'receiver_send_stats', 'Receiver_send_frequency_calc',
                 'Receiver_send_frequency'),

                ('Sender_account', 'sender_out_degree', 'Sender_out_degree_calc', 'Sender_out_degree'),
                ('Receiver_account', 'receiver_in_degree', 'Receiver_in_degree_calc', 'Receiver_in_degree'),
                ('Sender_account', 'sender_in_degree', 'Sender_in_degree_calc', 'Sender_in_degree'),
                ('Receiver_account', 'receiver_out_degree', 'Receiver_out_degree_calc', 'Receiver_out_degree'),

                ('Sender_account', 'sender_unique_receivers', 'Sender_unique_receivers_calc',
                 'Sender_unique_receivers'),
                ('Receiver_account', 'receiver_unique_senders', 'Receiver_unique_senders_calc',
                 'Receiver_unique_senders'),

                ('Sender_account', 'total_activity_counts', 'Total_activity_count_calc',
                 'Sender_total_activity_count'),
                ('Receiver_account', 'total_activity_counts', 'Total_activity_count_calc',
                 'Receiver_total_activity_count'),
            ]

            # 使用安全映射函数
            self._safe_map_features(dataset, target_indices, aggregated_stats_map, feature_mappings)

            # 处理配对交易特征
            pair_stats = aggregated_stats_map.get("pair_stats", pd.DataFrame())
            if not pair_stats.empty:
                try:
                    map_keys_pair = pd.MultiIndex.from_arrays([
                        dataset.loc[target_indices, 'Sender_account'],
                        dataset.loc[target_indices, 'Receiver_account']
                    ])
                    if 'Pair_transaction_count_calc' in pair_stats.columns:
                        dataset.loc[target_indices, 'Pair_transaction_count'] = map_keys_pair.map(
                            pair_stats['Pair_transaction_count_calc'])
                    if 'Pair_transaction_amount_calc' in pair_stats.columns:
                        dataset.loc[target_indices, 'Pair_transaction_amount'] = map_keys_pair.map(
                            pair_stats['Pair_transaction_amount_calc'])
                    if 'Pair_avg_amount_calc' in pair_stats.columns:
                        dataset.loc[target_indices, 'Pair_avg_amount'] = map_keys_pair.map(
                            pair_stats['Pair_avg_amount_calc'])
                    if 'Pair_time_span_days_calc' in pair_stats.columns:
                        dataset.loc[target_indices, 'Pair_time_span_days'] = map_keys_pair.map(
                            pair_stats['Pair_time_span_days_calc'])
                except Exception as e:
                    print(f"Warning: Failed to map pair features: {e}")

            # 处理图特征
            graph_features = aggregated_stats_map.get("graph_features", {})
            if graph_features:
                # 聚类系数
                if 'clustering_coef' in graph_features and not graph_features['clustering_coef'].empty:
                    dataset.loc[target_indices, 'Sender_clustering_coef'] = dataset.loc[
                        target_indices, 'Sender_account'].map(
                        graph_features['clustering_coef']['clustering_coef_calc'])
                    dataset.loc[target_indices, 'Receiver_clustering_coef'] = dataset.loc[
                        target_indices, 'Receiver_account'].map(
                        graph_features['clustering_coef']['clustering_coef_calc'])

                # PageRank
                if 'pagerank' in graph_features and not graph_features['pagerank'].empty:
                    dataset.loc[target_indices, 'Sender_pagerank'] = dataset.loc[
                        target_indices, 'Sender_account'].map(graph_features['pagerank']['pagerank_calc'])
                    dataset.loc[target_indices, 'Receiver_pagerank'] = dataset.loc[
                        target_indices, 'Receiver_account'].map(graph_features['pagerank']['pagerank_calc'])

                # 介数中心性
                if 'betweenness_centrality' in graph_features and not graph_features[
                    'betweenness_centrality'].empty:
                    dataset.loc[target_indices, 'Sender_betweenness_centrality'] = dataset.loc[
                        target_indices, 'Sender_account'].map(
                        graph_features['betweenness_centrality']['betweenness_centrality_calc'])
                    dataset.loc[target_indices, 'Receiver_betweenness_centrality'] = dataset.loc[
                        target_indices, 'Receiver_account'].map(
                        graph_features['betweenness_centrality']['betweenness_centrality_calc'])

                # 循环特征
                if 'cycles' in graph_features:
                    if 'has_2_cycle' in graph_features['cycles'] and not graph_features['cycles'][
                        'has_2_cycle'].empty:
                        dataset.loc[target_indices, 'Has_2_cycle'] = dataset.loc[
                            target_indices, 'Sender_account'].map(
                            graph_features['cycles']['has_2_cycle']['has_2_cycle_calc'])
                    if 'has_3_cycle' in graph_features['cycles'] and not graph_features['cycles'][
                        'has_3_cycle'].empty:
                        dataset.loc[target_indices, 'Has_3_cycle'] = dataset.loc[
                            target_indices, 'Sender_account'].map(
                            graph_features['cycles']['has_3_cycle']['has_3_cycle_calc'])

            current_target_date_idx += step_days
            processed_windows += 1

        print(f"Processed {processed_windows} windows successfully.")

        # 填充 NaN 值
        for col in self.feature_columns_list:
            if col in dataset.columns:
                dataset[col] = dataset[col].fillna(0.0)

        return dataset

    def _create_advanced_graph_features(self):
        """创建高级图特征（非滑动窗口）"""
        print("Creating advanced graph features...")

        # 新增：二阶邻居特征（类似GNN的2-hop邻居）
        # 这些特征将在滑动窗口中计算

        # 新增：账户角色特征
        self.df['Sender_out_in_ratio'] = np.where(
            self.df['Sender_in_degree'] > 0,
            self.df['Sender_out_degree'] / self.df['Sender_in_degree'],
            self.df['Sender_out_degree']
        )

        self.df['Receiver_out_in_ratio'] = np.where(
            self.df['Receiver_in_degree'] > 0,
            self.df['Receiver_out_degree'] / self.df['Receiver_in_degree'],
            self.df['Receiver_out_degree']
        )

        # 新增：相对活跃度
        self.df['Sender_relative_activity'] = np.where(
            self.df['Sender_total_activity_count'].mean() > 0,
            self.df['Sender_total_activity_count'] / self.df['Sender_total_activity_count'].mean(),
            0
        )

        self.df['Receiver_relative_activity'] = np.where(
            self.df['Receiver_total_activity_count'].mean() > 0,
            self.df['Receiver_total_activity_count'] / self.df['Receiver_total_activity_count'].mean(),
            0
        )

    def _create_time_series_features(self):
        """创建时间序列特征"""
        print("Creating time series features...")

        # 新增：交易时间间隔特征（需要在滑动窗口中计算）
        # 这里添加一些简单的时间特征

        # 时间戳转换为数值
        if 'Timestamp' in self.df.columns:
            self.df['Timestamp_numeric'] = self.df['Timestamp'].astype(np.int64) // 10 ** 9  # 转为秒

            # 计算与前一笔交易的时间差（同一账户）
            self.df = self.df.sort_values(['Sender_account', 'Timestamp'])
            self.df['Sender_time_since_last'] = self.df.groupby('Sender_account')['Timestamp_numeric'].diff()

            self.df = self.df.sort_values(['Receiver_account', 'Timestamp'])
            self.df['Receiver_time_since_last'] = self.df.groupby('Receiver_account')['Timestamp_numeric'].diff()

            # 恢复原排序
            self.df = self.df.sort_values(['Date', 'Time']).reset_index(drop=True)

            # 填充缺失值
            self.df['Sender_time_since_last'] = self.df['Sender_time_since_last'].fillna(86400)  # 默认1天
            self.df['Receiver_time_since_last'] = self.df['Receiver_time_since_last'].fillna(86400)

    def _create_temporal_features(self):
        """创建时间模式特征（增强版）"""
        print("Creating temporal features...")

        # 小时特征
        if 'Hour' in self.df.columns:
            self.df['Is_business_hour'] = ((self.df['Hour'] >= 9) & (self.df['Hour'] <= 17)).astype(int)
            self.df['Is_night_hour'] = ((self.df['Hour'] >= 22) | (self.df['Hour'] <= 6)).astype(int)
            self.df['Is_lunch_hour'] = ((self.df['Hour'] >= 12) & (self.df['Hour'] <= 14)).astype(int)
            self.df['Is_early_morning'] = ((self.df['Hour'] >= 4) & (self.df['Hour'] <= 7)).astype(int)
            self.df['Hour_sin'] = np.sin(2 * np.pi * self.df['Hour'] / 24)
            self.df['Hour_cos'] = np.cos(2 * np.pi * self.df['Hour'] / 24)

            # 新增：小时分组
            self.df['Hour_group'] = pd.cut(self.df['Hour'],
                                           bins=[-1, 6, 12, 18, 24],
                                           labels=['night', 'morning', 'afternoon', 'evening'])
            self.df['Hour_group_encoded'] = LabelEncoder().fit_transform(self.df['Hour_group'])

        # 分钟和秒特征
        if 'Minute' in self.df.columns:
            self.df['Minute_sin'] = np.sin(2 * np.pi * self.df['Minute'] / 60)
            self.df['Minute_cos'] = np.cos(2 * np.pi * self.df['Minute'] / 60)
            self.df['Is_round_minute'] = (self.df['Minute'] % 10 == 0).astype(int)

        # 日期特征
        self.df['DayOfWeek'] = self.df['Date'].dt.dayofweek
        self.df['Is_weekend'] = (self.df['DayOfWeek'] >= 5).astype(int)
        self.df['Is_monday'] = (self.df['DayOfWeek'] == 0).astype(int)
        self.df['Is_friday'] = (self.df['DayOfWeek'] == 4).astype(int)
        self.df['Day'] = self.df['Date'].dt.day
        self.df['Is_month_start'] = (self.df['Day'] <= 5).astype(int)
        self.df['Is_month_end'] = (self.df['Day'] >= 25).astype(int)
        self.df['Is_mid_month'] = ((self.df['Day'] >= 14) & (self.df['Day'] <= 16)).astype(int)

        # 周期性特征
        self.df['Day_sin'] = np.sin(2 * np.pi * self.df['Day'] / 31)
        self.df['Day_cos'] = np.cos(2 * np.pi * self.df['Day'] / 31)
        self.df['Week_sin'] = np.sin(2 * np.pi * self.df['DayOfWeek'] / 7)
        self.df['Week_cos'] = np.cos(2 * np.pi * self.df['DayOfWeek'] / 7)

        # 月份和季度
        self.df['Month_num'] = self.df['Date'].dt.month
        self.df['Quarter'] = self.df['Date'].dt.quarter
        self.df['Month_sin'] = np.sin(2 * np.pi * self.df['Month_num'] / 12)
        self.df['Month_cos'] = np.cos(2 * np.pi * self.df['Month_num'] / 12)

        # 新增：年内天数
        self.df['DayOfYear'] = self.df['Date'].dt.dayofyear
        self.df['DayOfYear_sin'] = np.sin(2 * np.pi * self.df['DayOfYear'] / 365)
        self.df['DayOfYear_cos'] = np.cos(2 * np.pi * self.df['DayOfYear'] / 365)

        # 新增：是否为节假日前后（简化版，可根据实际节假日调整）
        self.df['Is_near_holiday'] = (
                (self.df['Month_num'] == 12) & (self.df['Day'] >= 20) |  # 圣诞前
                (self.df['Month_num'] == 1) & (self.df['Day'] <= 10) |  # 新年后
                (self.df['Month_num'] == 7) & (self.df['Day'] <= 10)  # 假期季
        ).astype(int)

    def _create_transaction_pattern_features(self):
        """创建交易模式特征（增强版）"""
        print("Creating transaction pattern features...")

        # 编码分类变量
        categorical_cols = ['Payment_currency', 'Received_currency', 'Sender_bank_location',
                            'Receiver_bank_location', 'Payment_type']

        for col in categorical_cols:
            if col in self.df.columns:
                le = LabelEncoder()
                self.df[f'{col}_encoded'] = le.fit_transform(self.df[col].astype(str))
                self.encoders[col] = le

                # 新增：类别频率编码
                value_counts = self.df[col].value_counts()
                self.df[f'{col}_frequency'] = self.df[col].map(value_counts)
                self.df[f'{col}_frequency_log'] = np.log1p(self.df[f'{col}_frequency'])

        # 新增：支付类型组合特征
        if 'Payment_type' in self.df.columns:
            # 高风险支付类型
            high_risk_payment_types = ['Cash Deposit', 'Cash Withdrawal', 'Wire Transfer']
            self.df['Is_high_risk_payment'] = self.df['Payment_type'].isin(high_risk_payment_types).astype(int)

            # 新增：现金相关交易
            self.df['Is_cash_transaction'] = self.df['Payment_type'].str.contains('Cash', case=False,
                                                                                  na=False).astype(int)

            # 新增：电子交易
            electronic_types = ['ACH', 'Wire Transfer', 'Credit Card', 'Debit Card']
            self.df['Is_electronic_payment'] = self.df['Payment_type'].isin(electronic_types).astype(int)

    def _create_behavioral_change_features(self):
        """创建行为变化特征"""
        print("Creating behavioral change features...")

        # 新增：金额变化率
        if 'Sender_avg_amount' in self.df.columns:
            self.df['Sender_amount_deviation'] = np.where(
                self.df['Sender_avg_amount'] > 0,
                (self.df['Amount'] - self.df['Sender_avg_amount']) / self.df['Sender_avg_amount'],
                0
            )

            self.df['Receiver_amount_deviation'] = np.where(
                self.df['Receiver_avg_amount'] > 0,
                (self.df['Amount'] - self.df['Receiver_avg_amount']) / self.df['Receiver_avg_amount'],
                0
            )

            # 标记异常大额交易
            self.df['Is_sender_unusual_amount'] = (
                    (self.df['Sender_amount_deviation'] > 2) |  # 超过平均值2倍
                    (self.df['Amount'] > self.df['Sender_avg_amount'] + 2 * self.df['Sender_amount_std'])
            ).astype(int)

            self.df['Is_receiver_unusual_amount'] = (
                    (self.df['Receiver_amount_deviation'] > 2) |
                    (self.df['Amount'] > self.df['Receiver_avg_amount'] + 2 * self.df['Receiver_amount_std'])
            ).astype(int)

        # 新增：频率变化
        if 'Sender_send_frequency' in self.df.columns:
            # 计算历史平均频率（这是一个简化版本）
            self.df['Sender_frequency_change'] = np.where(
                self.df['Sender_send_frequency'].shift(1) > 0,
                (self.df['Sender_send_frequency'] - self.df['Sender_send_frequency'].shift(1)) / self.df[
                    'Sender_send_frequency'].shift(1),
                0
            )

            self.df['Receiver_frequency_change'] = np.where(
                self.df['Receiver_receive_frequency'].shift(1) > 0,
                (self.df['Receiver_receive_frequency'] - self.df['Receiver_receive_frequency'].shift(1)) / self.df[
                    'Receiver_receive_frequency'].shift(1),
                0
            )

        # 新增：新关系标记
        if 'Pair_transaction_count' in self.df.columns:
            self.df['Is_new_relationship'] = (self.df['Pair_transaction_count'] == 1).astype(int)
            self.df['Is_rare_relationship'] = (self.df['Pair_transaction_count'] <= 2).astype(int)

    def _create_currency_and_cross_border_features(self):
        """创建多币种和跨境增强特征"""
        print("Creating currency and cross-border features...")

        # 新增：具体的跨境路径
        if 'Sender_bank_location' in self.df.columns and 'Receiver_bank_location' in self.df.columns:
            self.df['Cross_border_path'] = self.df['Sender_bank_location'] + '_to_' + self.df[
                'Receiver_bank_location']

            # 编码跨境路径
            le = LabelEncoder()
            self.df['Cross_border_path_encoded'] = le.fit_transform(self.df['Cross_border_path'])
            self.encoders['Cross_border_path'] = le

            # 高风险国家/地区标记（示例）
            high_risk_locations = ['UAE', 'Nigeria', 'Panama', 'Bahamas']  # 示例高风险地区
            self.df['Is_high_risk_sender_location'] = self.df['Sender_bank_location'].isin(
                high_risk_locations).astype(int)
            self.df['Is_high_risk_receiver_location'] = self.df['Receiver_bank_location'].isin(
                high_risk_locations).astype(int)
            self.df['Is_high_risk_transaction'] = (
                    self.df['Is_high_risk_sender_location'] | self.df['Is_high_risk_receiver_location']
            ).astype(int)

        # 新增：货币对特征
        if 'Payment_currency' in self.df.columns and 'Received_currency' in self.df.columns:
            self.df['Currency_pair'] = self.df['Payment_currency'] + '_' + self.df['Received_currency']

            # 编码货币对
            le = LabelEncoder()
            self.df['Currency_pair_encoded'] = le.fit_transform(self.df['Currency_pair'])
            self.encoders['Currency_pair'] = le

            # 常见货币标记
            major_currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'UK pounds', 'US Dollar']
            self.df['Is_major_currency_payment'] = self.df['Payment_currency'].isin(major_currencies).astype(int)
            self.df['Is_major_currency_received'] = self.df['Received_currency'].isin(major_currencies).astype(int)

            # 新增：是否涉及加密货币或特殊货币（如果数据中有）
            crypto_currencies = ['Bitcoin', 'BTC', 'Ethereum', 'ETH', 'Crypto']  # 示例
            self.df['Is_crypto_involved'] = (
                    self.df['Payment_currency'].isin(crypto_currencies) |
                    self.df['Received_currency'].isin(crypto_currencies)
            ).astype(int)

    def _create_risk_score_features(self):
        """创建基于规则的风险评分特征（增强版）"""
        print("Creating risk score features...")

        # 初始化风险评分
        self.df['Risk_score'] = 0

        # 大额交易风险（分级）
        if 'Amount' in self.df.columns:
            amount_percentiles = self.df['Amount'].quantile([0.9, 0.95, 0.99])
            self.df['Risk_score'] += (self.df['Amount'] > amount_percentiles[0.9]).astype(int) * 1
            self.df['Risk_score'] += (self.df['Amount'] > amount_percentiles[0.95]).astype(int) * 2
            self.df['Risk_score'] += (self.df['Amount'] > amount_percentiles[0.99]).astype(int) * 3

        # 跨境交易风险
        self.df['Risk_score'] += self.df['Is_cross_border'] * 2

        # 货币不匹配风险
        self.df['Risk_score'] += self.df['Currency_mismatch'] * 2

        # 非工作时间交易风险
        if 'Is_business_hour' in self.df.columns:
            self.df['Risk_score'] += (1 - self.df['Is_business_hour']) * 1

        # 深夜交易额外风险
        if 'Is_night_hour' in self.df.columns:
            self.df['Risk_score'] += self.df['Is_night_hour'] * 2

        # 高频交易风险
        if 'Sender_send_count' in self.df.columns:
            self.df['Risk_score'] += (self.df['Sender_send_count'] > 10).astype(int) * 2
            self.df['Risk_score'] += (self.df['Sender_send_count'] > 50).astype(int) * 3

        # 整数金额风险
        self.df['Risk_score'] += self.df['Is_large_round'] * 2

        # 现金交易风险
        if 'Is_cash_transaction' in self.df.columns:
            self.df['Risk_score'] += self.df['Is_cash_transaction'] * 3

        # 新关系风险
        if 'Is_new_relationship' in self.df.columns:
            self.df['Risk_score'] += self.df['Is_new_relationship'] * 1

        # 异常金额风险
        if 'Is_sender_unusual_amount' in self.df.columns:
            self.df['Risk_score'] += self.df['Is_sender_unusual_amount'] * 3
            self.df['Risk_score'] += self.df['Is_receiver_unusual_amount'] * 3

        # 高风险地区
        if 'Is_high_risk_transaction' in self.df.columns:
            self.df['Risk_score'] += self.df['Is_high_risk_transaction'] * 4

        # 循环交易风险
        if 'Has_2_cycle' in self.df.columns:
            self.df['Risk_score'] += self.df['Has_2_cycle'] * 3
        if 'Has_3_cycle' in self.df.columns:
            self.df['Risk_score'] += self.df['Has_3_cycle'] * 2

        # 创建风险等级
        risk_thresholds = self.df['Risk_score'].quantile([0.7, 0.9, 0.95])
        self.df['Risk_level'] = pd.cut(
            self.df['Risk_score'],
            bins=[-np.inf, risk_thresholds[0.7], risk_thresholds[0.9], risk_thresholds[0.95], np.inf],
            labels=['low', 'medium', 'high', 'very_high']
        )
        self.df['Risk_level_encoded'] = LabelEncoder().fit_transform(self.df['Risk_level'])

    def _validate_time_window(self, hist_start: pd.Timestamp, hist_end: pd.Timestamp,
                              target_start: pd.Timestamp) -> bool:
        """验证时间窗口是否符合无数据泄露要求"""
        return hist_end <= target_start

    def _safe_map_features(self, dataset: pd.DataFrame, target_indices: pd.Index,
                           stats_dict: dict, feature_mappings: list):
        """安全地映射特征，处理缺失值和异常情况"""
        for mapping in feature_mappings:
            account_col, stats_key, calc_col, target_col = mapping

            if stats_key in stats_dict and not stats_dict[stats_key].empty:
                if calc_col in stats_dict[stats_key].columns:
                    try:
                        mapped_values = dataset.loc[target_indices, account_col].map(
                            stats_dict[stats_key][calc_col]
                        )
                        dataset.loc[target_indices, target_col] = mapped_values
                    except Exception as e:
                        print(f"Warning: Failed to map {target_col}: {e}")

    def get_feature_summary(self):
        """返回特征工程的总结信息"""
        feature_summary = {}

        # 获取所有数值型特征
        numeric_features = self.df.select_dtypes(include=[np.number]).columns

        for col in numeric_features:
            if col not in ['Is_laundering', 'Laundering_type']:  # 排除目标变量
                feature_summary[col] = {
                    'non_null_count': self.df[col].count(),
                    'null_count': self.df[col].isnull().sum(),
                    'mean': self.df[col].mean(),
                    'std': self.df[col].std(),
                    'min': self.df[col].min(),
                    'max': self.df[col].max(),
                    'unique_values': self.df[col].nunique()
                }

        return feature_summary



#################################################################################################################

    def exploratory_data_analysis(self):
        """
        探索性数据分析和可视化
        """
        print("Performing exploratory data analysis...")

        try:
            # 创建图表目录
            os.makedirs('eda_plots', exist_ok=True)

            # 1. 基础统计
            self._plot_basic_statistics()

            # 2. 目标变量分布
            self._plot_target_distribution()

            # 3. 时间模式分析
            self._plot_temporal_patterns()

            # 4. 金额分布分析
            self._plot_amount_distribution()

            # 5. 图特征分析
            self._plot_graph_features()

            # 6. 相关性分析
            self._plot_correlation_analysis()

            print("EDA completed. Plots saved in 'eda_plots' directory.")

        except Exception as e:
            print(f"Error in EDA: {e}")

    def _plot_basic_statistics(self):
        """
        基础统计图表
        """
        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))

            # 数据集大小
            axes[0, 0].bar(['Total', 'Fraud', 'Normal'],
                           [len(self.df), self.df['Is_laundering'].sum(),
                            len(self.df) - self.df['Is_laundering'].sum()])
            axes[0, 0].set_title('Dataset Composition')
            axes[0, 0].set_ylabel('Count')

            # 欺诈率
            fraud_rate = self.df['Is_laundering'].mean()
            axes[0, 1].pie([fraud_rate, 1 - fraud_rate], labels=['Fraud', 'Normal'], autopct='%1.2f%%')
            axes[0, 1].set_title('Fraud Rate')

            # 按月份的交易量
            monthly_counts = self.df.groupby(self.df['Date'].dt.to_period('M')).size()
            monthly_counts.plot(kind='bar', ax=axes[1, 0])
            axes[1, 0].set_title('Monthly Transaction Volume')
            axes[1, 0].tick_params(axis='x', rotation=45)

            # 洗钱类型分布
            type_counts = self.df['Laundering_type'].value_counts().head(10)
            type_counts.plot(kind='barh', ax=axes[1, 1])
            axes[1, 1].set_title('Top 10 Laundering Types')

            plt.tight_layout()
            plt.savefig('eda_plots/basic_statistics.png', dpi=300, bbox_inches='tight')
            plt.close()

        except Exception as e:
            print(f"Error plotting basic statistics: {e}")

    def _plot_target_distribution(self):
        """
        目标变量分布
        """
        try:
            fig, axes = plt.subplots(1, 2, figsize=(15, 6))

            # Is_laundering分布
            self.df['Is_laundering'].value_counts().plot(kind='bar', ax=axes[0])
            axes[0].set_title('Is_laundering Distribution')
            axes[0].set_xlabel('Is_laundering')
            axes[0].set_ylabel('Count')

            # Laundering_type分布（只显示前15个）
            top_types = self.df['Laundering_type'].value_counts().head(15)
            top_types.plot(kind='barh', ax=axes[1])
            axes[1].set_title('Top 15 Laundering Types')

            plt.tight_layout()
            plt.savefig('eda_plots/target_distribution.png', dpi=300, bbox_inches='tight')
            plt.close()

        except Exception as e:
            print(f"Error plotting target distribution: {e}")

    def _plot_temporal_patterns(self):
        """
        时间模式分析
        """
        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))

            # 按小时的欺诈率
            if 'Hour' in self.df.columns:
                hourly_fraud = self.df.groupby('Hour')['Is_laundering'].agg(['count', 'sum', 'mean'])
                hourly_fraud['mean'].plot(kind='bar', ax=axes[0, 0])
                axes[0, 0].set_title('Fraud Rate by Hour')
                axes[0, 0].set_ylabel('Fraud Rate')

            # 按星期几的欺诈率
            if 'DayOfWeek' in self.df.columns:
                daily_fraud = self.df.groupby('DayOfWeek')['Is_laundering'].mean()
                daily_fraud.plot(kind='bar', ax=axes[0, 1])
                axes[0, 1].set_title('Fraud Rate by Day of Week')
                axes[0, 1].set_xticklabels(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])

            # 按月份的欺诈趋势
            monthly_fraud = self.df.groupby(self.df['Date'].dt.to_period('M'))['Is_laundering'].mean()
            monthly_fraud.plot(ax=axes[1, 0])
            axes[1, 0].set_title('Monthly Fraud Rate Trend')
            axes[1, 0].tick_params(axis='x', rotation=45)

            # 工作时间vs非工作时间
            if 'Is_business_hour' in self.df.columns:
                business_hour_fraud = self.df.groupby('Is_business_hour')['Is_laundering'].mean()
                business_hour_fraud.plot(kind='bar', ax=axes[1, 1])
                axes[1, 1].set_title('Fraud Rate: Business vs Non-Business Hours')
                axes[1, 1].set_xticklabels(['Non-Business', 'Business'])

            plt.tight_layout()
            plt.savefig('eda_plots/temporal_patterns.png', dpi=300, bbox_inches='tight')
            plt.close()

        except Exception as e:
            print(f"Error plotting temporal patterns: {e}")

    def _plot_amount_distribution(self):
        """
        金额分布分析
        """
        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))

            # 金额分布（对数尺度）
            fraud_amounts = self.df[self.df['Is_laundering'] == 1]['Amount']
            normal_amounts = self.df[self.df['Is_laundering'] == 0]['Amount']

            axes[0, 0].hist([np.log1p(normal_amounts), np.log1p(fraud_amounts)],
                            bins=50, alpha=0.7, label=['Normal', 'Fraud'])
            axes[0, 0].set_title('Amount Distribution (Log Scale)')
            axes[0, 0].set_xlabel('Log(Amount + 1)')
            axes[0, 0].legend()

            # 金额箱线图
            amount_data = [normal_amounts.sample(min(10000, len(normal_amounts))),
                           fraud_amounts if len(fraud_amounts) > 0 else [0]]
            axes[0, 1].boxplot(amount_data, labels=['Normal', 'Fraud'])
            axes[0, 1].set_title('Amount Distribution by Fraud Status')
            axes[0, 1].set_yscale('log')

            # 整数金额分析
            if 'Is_round_amount' in self.df.columns:
                round_fraud = self.df.groupby('Is_round_amount')['Is_laundering'].mean()
                round_fraud.plot(kind='bar', ax=axes[1, 0])
                axes[1, 0].set_title('Fraud Rate: Round vs Non-Round Amounts')
                axes[1, 0].set_xticklabels(['Non-Round', 'Round'])

            # 大额整数金额分析
            if 'Is_large_round' in self.df.columns:
                large_round_fraud = self.df.groupby('Is_large_round')['Is_laundering'].mean()
                large_round_fraud.plot(kind='bar', ax=axes[1, 1])
                axes[1, 1].set_title('Fraud Rate: Large Round Amounts')
                axes[1, 1].set_xticklabels(['Non-Large-Round', 'Large-Round'])

            plt.tight_layout()
            plt.savefig('eda_plots/amount_distribution.png', dpi=300, bbox_inches='tight')
            plt.close()

        except Exception as e:
            print(f"Error plotting amount distribution: {e}")

    def _plot_graph_features(self):
        """
        图特征分析
        """
        try:
            graph_features = ['Sender_in_degree', 'Sender_out_degree', 'Sender_pagerank',
                              'Receiver_in_degree', 'Receiver_out_degree', 'Receiver_pagerank']

            available_features = [f for f in graph_features if f in self.df.columns]

            if not available_features:
                return

            fig, axes = plt.subplots(2, 3, figsize=(18, 12))
            axes = axes.flatten()

            for i, feature in enumerate(available_features[:6]):
                if feature in self.df.columns:
                    fraud_values = self.df[self.df['Is_laundering'] == 1][feature]
                    normal_values = self.df[self.df['Is_laundering'] == 0][feature]

                    # 采样以提高绘图效率
                    normal_sample = normal_values.sample(min(10000, len(normal_values)))

                    axes[i].hist([normal_sample, fraud_values], bins=50, alpha=0.7,
                                 label=['Normal', 'Fraud'], density=True)
                    axes[i].set_title(f'{feature} Distribution')
                    axes[i].legend()
                    axes[i].set_yscale('log')

            plt.tight_layout()
            plt.savefig('eda_plots/graph_features.png', dpi=300, bbox_inches='tight')
            plt.close()

        except Exception as e:
            print(f"Error plotting graph features: {e}")

    def _plot_correlation_analysis(self):
        """
        相关性分析
        """
        try:
            # 选择数值特征
            numeric_features = self.df.select_dtypes(include=[np.number]).columns
            numeric_features = [f for f in numeric_features if f not in ['Sender_account', 'Receiver_account']]

            if len(numeric_features) > 1:
                # 计算相关性矩阵
                corr_matrix = self.df[numeric_features].corr()

                # 与目标变量的相关性
                target_corr = corr_matrix['Is_laundering'].abs().sort_values(ascending=False)

                fig, axes = plt.subplots(1, 2, figsize=(20, 8))

                # 热图
                sns.heatmap(corr_matrix.iloc[:20, :20], annot=False, ax=axes[0], cmap='coolwarm')
                axes[0].set_title('Feature Correlation Matrix (Top 20)')

                # 与目标变量的相关性
                target_corr.head(20).plot(kind='barh', ax=axes[1])
                axes[1].set_title('Top 20 Features Correlated with Fraud')

                plt.tight_layout()
                plt.savefig('eda_plots/correlation_analysis.png', dpi=300, bbox_inches='tight')
                plt.close()

        except Exception as e:
            print(f"Error plotting correlation analysis: {e}")

    def prepare_features_for_modeling(self):
        """
        为建模准备特征 - 统一特征管理（优化版）
        """
        print("Preparing features for modeling...")

        # 定义必须排除的列（目标变量、标识符、临时列）
        exclude_cols = [
            'Is_laundering', 'Laundering_type', 'Date', 'Time', 'Month', 'Timestamp',
            'Sender_account', 'Receiver_account'
        ]

        # 选择特征列
        self.feature_columns = [col for col in self.df.columns if col not in exclude_cols]

        # 验证目标列确实被排除
        for target_col in ['Is_laundering', 'Laundering_type']:
            if target_col in self.feature_columns:
                raise ValueError(f"错误：目标列 {target_col} 仍在特征列中！")

        print(f"Selected {len(self.feature_columns)} features for modeling")
        print("Feature columns:", self.feature_columns[:10], "..." if len(self.feature_columns) > 10 else "")

        # 关键优化：确保数据已分割，并且只在分割后的数据上操作
        if not hasattr(self, 'train_df') or self.train_df is None:
            # 如果在调用此函数时数据还未分割，应抛出错误或提前返回
            # 避免对 self.df 进行任何形式的 fit/transform 操作
            print("警告：数据尚未分割，跳过缺失值填充。请先调用 split_data_by_month()")
            return

        print("处理训练集和测试集的缺失值...")
        # 使用训练集的信息来填充训练集和测试集
        for col in self.feature_columns:
            if col not in self.train_df.columns:
                continue

            # 处理分类/对象类型
            if pd.api.types.is_object_dtype(self.train_df[col]) or pd.api.types.is_categorical_dtype(
                    self.train_df[col]):
                fill_value = 'unknown'
                # 对于Categorical类型，确保 'unknown' 是一个合法的类别
                if pd.api.types.is_categorical_dtype(self.train_df[col]):
                    if fill_value not in self.train_df[col].cat.categories:
                        self.train_df[col] = self.train_df[col].cat.add_categories([fill_value])
                    if fill_value not in self.test_df[col].cat.categories:
                        self.test_df[col] = self.test_df[col].cat.add_categories([fill_value])

                self.train_df[col] = self.train_df[col].fillna(fill_value)
                self.test_df[col] = self.test_df[col].fillna(fill_value)

            # 处理数值类型
            else:
                # 核心原则：只从训练集计算统计量
                train_median = self.train_df[col].median()
                self.train_df[col] = self.train_df[col].fillna(train_median)
                self.test_df[col] = self.test_df[col].fillna(train_median)

    def train_models(self, task_mode=None):
        """
        训练多种模型 - 修正数据泄露问题并优化内存使用

        Parameters:
        -----------
        task_mode : str, optional
            指定训练任务类型:
            - 'Is_laundering' 或 'binary': 仅执行二分类任务
            - 'Laundering_type' 或 'multiclass': 仅执行多分类任务
            - None 或 'both': 执行所有任务（默认）
        """
        print("Training models...")

        # 准备特征
        self.prepare_features_for_modeling()

        # 验证数据已分割
        if self.train_df is None or self.test_df is None:
            raise ValueError("Please split data first using split_data_by_month()")

        # 根据数据集类型自动调整任务模式
        if task_mode is None:
            if not self.supports_multiclass:
                task_mode = 'binary'
                print(f"数据集类型 {self.dataset_type} 不支持多分类，自动设置为二分类模式")
            else:
                task_mode = 'both'

        # 标准化任务模式参数
        if task_mode is not None:
            task_mode = task_mode.lower()
            if task_mode in ['is_laundering', 'binary', '二分类']:
                task_mode = 'binary'
            elif task_mode in ['laundering_type', 'multiclass', '多分类']:
                task_mode = 'multiclass'
            elif task_mode in ['both', 'all', '全部']:
                task_mode = None
            else:
                print(f"警告: 未识别的任务模式 '{task_mode}'，将执行所有任务")
                task_mode = None

        # 根据任务模式和数据集支持情况决定执行哪些任务
        execute_binary = task_mode is None or task_mode == 'binary'
        execute_multiclass = (task_mode is None or task_mode == 'multiclass') and self.supports_multiclass

        print(f"\n=== 任务执行计划 ===")
        print(f"数据集类型: {self.dataset_type}")
        print(f"支持多分类: {self.supports_multiclass}")
        print(f"二分类任务: {'是' if execute_binary else '否'}")
        print(f"多分类任务: {'是' if execute_multiclass else '否'}")

        # 顺序执行任务以优化内存使用
        if execute_binary:
            self._execute_binary_classification()

        if execute_multiclass:
            self._execute_multiclass_classification()

    def _execute_binary_classification(self):
        """
        执行二分类任务 - 使用统一的特征列管理
        """
        print("\n" + "=" * 50)
        print("开始执行二分类任务")
        print("=" * 50)

        # 使用已经准备好的特征列（已排除所有目标列）
        binary_feature_columns = self.feature_columns.copy()

        # 验证没有数据泄露
        self._validate_no_data_leakage(binary_feature_columns, 'binary')

        print(f"二分类任务使用的特征列数量: {len(binary_feature_columns)}")

        # 准备二分类训练数据
        print("\n=== 准备二分类数据 ===")
        X_train_binary = self.train_df[binary_feature_columns].copy()
        y_train_binary = self.train_df['Is_laundering']

        X_test_binary = self.test_df[binary_feature_columns].copy()
        y_test_binary = self.test_df['Is_laundering']

        print(f"二分类训练集形状: {X_train_binary.shape}")
        print(f"二分类目标分布: {y_train_binary.value_counts().to_dict()}")

        # 数据预处理
        print("\n=== 二分类数据预处理 ===")
        X_train_processed, X_test_processed = self._preprocess_features(
            X_train_binary, X_test_binary, 'binary'
        )

        # 训练模型
        print("\n=== 训练二分类模型 ===")
        self._train_binary_models(
            X_train_processed, y_train_binary,
            X_test_processed, y_test_binary
        )

        # 清理内存
        del X_train_binary, X_test_binary, X_train_processed, X_test_processed
        import gc
        gc.collect()
        print("二分类任务完成，已清理相关数据")

    def _execute_multiclass_classification(self):
        """
        执行多分类任务 - 使用统一的特征列管理（增强安全检查）
        """
        print("\n" + "=" * 50)
        print("开始执行多分类任务")
        print("=" * 50)

        # 检查数据集是否支持多分类
        if not self.supports_multiclass:
            print("当前数据集不支持多分类任务，跳过执行")
            return

        # 检查必要的列是否存在
        required_columns = ['Laundering_type', 'Is_laundering']
        for col in required_columns:
            if col not in self.train_df.columns:
                print(f"错误：训练集中 {col} 列不存在，无法执行多分类任务")
                return
            if col not in self.test_df.columns:
                print(f"错误：测试集中 {col} 列不存在，无法执行多分类任务")
                return

        # 检查 Laundering_type 列是否有有效值
        if self.train_df['Laundering_type'].isna().all():
            print("错误：Laundering_type 列全部为空值，无法执行多分类任务")
            return

        # 使用已经准备好的特征列（已排除所有目标列）
        multiclass_feature_columns = self.feature_columns.copy()
        
        # 双重检查：确保目标列不在特征列中
        target_cols_to_exclude = ['Is_laundering', 'Laundering_type', 'Is Laundering']
        multiclass_feature_columns = [col for col in multiclass_feature_columns 
                                     if col not in target_cols_to_exclude]

        # 验证特征列在数据中存在
        missing_features = [col for col in multiclass_feature_columns 
                           if col not in self.train_df.columns or col not in self.test_df.columns]
        if missing_features:
            print(f"警告：以下特征列在数据中不存在，将被排除: {missing_features}")
            multiclass_feature_columns = [col for col in multiclass_feature_columns 
                                         if col not in missing_features]

        # 验证没有数据泄露
        self._validate_no_data_leakage(multiclass_feature_columns, 'multiclass')

        print(f"多分类任务使用的特征列数量: {len(multiclass_feature_columns)}")

        # 准备多分类训练数据
        print("\n=== 准备多分类数据 ===")
        try:
            X_train_multi = self.train_df[multiclass_feature_columns].copy()
            y_train_multi = self.train_df['Laundering_type']

            X_test_multi = self.test_df[multiclass_feature_columns].copy()
            y_test_multi = self.test_df['Laundering_type']
            y_test_binary = self.test_df['Is_laundering']  # 用于评估欺诈检测性能

            print(f"多分类训练集形状: {X_train_multi.shape}")
            print(f"多分类目标分布前10: {y_train_multi.value_counts().head(10).to_dict()}")

            # 数据预处理
            print("\n=== 多分类数据预处理 ===")
            X_train_processed, X_test_processed = self._preprocess_features(
                X_train_multi, X_test_multi, 'multi'
            )

            # 编码多分类目标
            le_multi = LabelEncoder()
            le_multi.fit(self.df['Laundering_type'].astype(str))
            self.encoders['laundering_type'] = le_multi

            # 安全地转换训练和测试集
            y_train_multi_encoded = le_multi.transform(y_train_multi.astype(str))
            y_test_multi_encoded = le_multi.transform(y_test_multi.astype(str))

            # 打印多分类目标映射关系
            print("\n多分类目标映射")
            mapping_multi = dict(zip(le_multi.classes_, le_multi.transform(le_multi.classes_)))
            for i, (k, v) in enumerate(mapping_multi.items()):
                print(f"  {k} -> {v}")

            # 训练模型
            print("\n=== 训练多分类模型 ===")
            self._train_multiclass_models(
                X_train_processed, y_train_multi_encoded,
                X_test_processed, y_test_multi_encoded, y_test_binary
            )

            # 清理内存
            del X_train_multi, X_test_multi, X_train_processed, X_test_processed
            del y_train_multi_encoded, y_test_multi_encoded
            import gc
            gc.collect()
            print("多分类任务完成，已清理相关数据")

        except KeyError as e:
            print(f"数据访问错误: {e}")
            print("可用的训练集列:", list(self.train_df.columns))
            print("可用的测试集列:", list(self.test_df.columns))
            print("请检查数据处理流程")
            return
        except Exception as e:
            print(f"多分类任务执行失败: {e}")
            import traceback
            traceback.print_exc()
            return

    def _validate_no_data_leakage(self, feature_columns, task_type):
        """
        验证特征列中没有目标变量，防止数据泄露
        """
        target_columns = ['Is_laundering', 'Laundering_type']

        # 检查是否有目标列在特征列中
        leakage_cols = [col for col in feature_columns if col in target_columns]

        if leakage_cols:
            raise ValueError(f"数据泄露错误：{task_type} 任务的特征列中包含目标列: {leakage_cols}")

        # 检查是否有可疑的列名
        suspicious_cols = []
        suspicious_keywords = ['laundering', 'fraud', 'illegal', 'suspicious', 'target', 'label']

        for col in feature_columns:
            col_lower = col.lower()
            if any(keyword in col_lower for keyword in suspicious_keywords):
                # 排除一些合法的特征名
                if col not in ['Is_large_round', 'Risk_score']:  # 这些是合法的特征
                    suspicious_cols.append(col)

        if suspicious_cols:
            print(f"警告：发现可能的数据泄露列: {suspicious_cols}")
            print("请确认这些列是否为合法特征，而非目标变量")

        print(f"✓ {task_type} 特征列验证通过，共 {len(feature_columns)} 个特征")

    def _preprocess_features(self, X_train, X_test, task_type):
        """
        特征预处理 - 保留特征名称信息
        """
        print(f"开始 {task_type} 特征预处理...")

        # 保存原始特征列名
        feature_columns = X_train.columns.tolist()

        # 保存特征名称到实例变量
        if not hasattr(self, 'feature_names_by_task'):
            self.feature_names_by_task = {}
        self.feature_names_by_task[task_type] = feature_columns

        # 复制数据以避免修改原始数据
        X_train_proc = X_train.copy()
        X_test_proc = X_test.copy()

        # 将非数值型特征转换为数值型
        encoder_key = f'{task_type}_encoders'
        if encoder_key not in self.encoders:
            self.encoders[encoder_key] = {}

        categorical_columns = []
        for col in X_train_proc.columns:
            if X_train_proc[col].dtype == 'object' or X_train_proc[col].dtype.name == 'category':
                categorical_columns.append(col)

        print(f"发现 {len(categorical_columns)} 个分类特征需要编码")

        # 批量处理分类特征
        for col in categorical_columns:
            le = LabelEncoder()

            # 使用更内存友好的方式处理
            train_values = X_train_proc[col].astype(str)
            test_values = X_test_proc[col].astype(str)

            # 获取所有唯一值并拟合编码器
            all_values = pd.concat([train_values, test_values]).unique()
            le.fit(all_values)

            # 转换
            X_train_proc[col] = le.transform(train_values)
            X_test_proc[col] = le.transform(test_values)

            self.encoders[encoder_key][col] = le

        # 特征缩放
        scaler_key = f'{task_type}_scaler'
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train_proc)
        X_test_scaled = scaler.transform(X_test_proc)
        self.scalers[scaler_key] = scaler

        print(f"{task_type} 特征预处理完成")
        print(f"  训练集形状: {X_train_scaled.shape}")
        print(f"  测试集形状: {X_test_scaled.shape}")
        print(f"  保存的特征名称数量: {len(feature_columns)}")

        return X_train_scaled, X_test_scaled

    def get_feature_info(self):
        """
        获取当前特征列的详细信息，用于调试和验证
        """
        info = {
            "total_columns": len(self.df.columns) if hasattr(self, 'df') and self.df is not None else 0,
            "feature_columns": len(self.feature_columns) if hasattr(self, 'feature_columns') else 0,
            "feature_names": self.feature_columns[:10] if hasattr(self, 'feature_columns') else []
        }

        # 检查是否有目标列在特征列中
        if hasattr(self, 'feature_columns'):
            target_in_features = []
            for target in ['Is_laundering', 'Laundering_type']:
                if target in self.feature_columns:
                    target_in_features.append(target)
            info["targets_in_features"] = target_in_features
            info["has_data_leakage"] = len(target_in_features) > 0

        # 检查各任务的特征信息
        if hasattr(self, 'feature_names_by_task'):
            info["features_by_task"] = {}
            for task, features in self.feature_names_by_task.items():
                info["features_by_task"][task] = {
                    "count": len(features),
                    "sample": features[:5]
                }

        return info

    def print_feature_summary(self):
        """
        打印特征摘要信息
        """
        print("\n=== 特征摘要信息 ===")
        info = self.get_feature_info()

        print(f"总列数: {info['total_columns']}")
        print(f"特征列数: {info['feature_columns']}")

        if info.get('has_data_leakage'):
            print(f"⚠️  警告：发现数据泄露！目标列在特征中: {info['targets_in_features']}")
        else:
            print("✓ 无数据泄露")

        if 'features_by_task' in info:
            print("\n各任务特征信息:")
            for task, task_info in info['features_by_task'].items():
                print(f"  {task}: {task_info['count']} 个特征")

        print("\n特征示例:", info.get('feature_names', []))


    def _train_binary_models(self, X_train, y_train, X_test, y_test):
        """
        训练二分类模型 - 内存优化版本
        目标TPR设定为95%，保存详细评估指标
        """
        print("\n=== Training Binary Classification Models ===")

        # 计算类权重
        class_weights = compute_class_weight('balanced', classes=np.unique(y_train), y=y_train)
        class_weight_dict = {0: class_weights[0], 1: class_weights[1]}
        # from lightgbm import LGBMClassifier
        # from sklearn.ensemble import RandomForestClassifier
        # from sklearn.linear_model import LogisticRegression
        # from sklearn.naive_bayes import GaussianNB, BernoulliNB
        # 添加多种模型，包括贝叶斯模型
        models = {
            'XGBoost': xgb.XGBClassifier(
                n_estimators=100,
                max_depth=6,
                learning_rate=0.1,
                scale_pos_weight=class_weights[1] / class_weights[0],
                random_state=42,
                eval_metric='logloss'
            ),
            # 'LightGBM': LGBMClassifier(
            #     n_estimators=100,
            #     max_depth=6,
            #     learning_rate=0.1,
            #     class_weight='balanced',
            #     random_state=42,
            #     verbose=-1
            # ),
            # 'RandomForest': RandomForestClassifier(
            #     n_estimators=100,
            #     max_depth=10,
            #     class_weight='balanced',
            #     random_state=42,
            #     n_jobs=-1
            # ),
            # 'LogisticRegression': LogisticRegression(
            #     class_weight='balanced',
            #     random_state=42,
            #     max_iter=1000
            # ),
            # 'GaussianNB': GaussianNB(),  # 高斯朴素贝叶斯模型
            # 'BernoulliNB': BernoulliNB()  # 伯努利朴素贝叶斯模型
        }

        if 'binary' not in self.models:
            self.models['binary'] = {}

        # 顺序训练模型以节省内存
        for name, model in models.items():
            print(f"\nTraining {name}...")

            try:
                # 直接使用原始数据训练，不使用SMOTE
                model.fit(X_train, y_train)

                # 预测概率
                y_pred_proba = model.predict_proba(X_test)[:, 1]

                # 计算ROC曲线，寻找达到95%TPR的阈值
                fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba)
                # 找到最接近95%TPR的阈值
                target_tpr = 0.95
                idx = np.argmin(np.abs(tpr - target_tpr))
                optimal_threshold = thresholds[idx]
                actual_tpr = tpr[idx]
                actual_fpr = fpr[idx]

                # 使用找到的阈值进行预测
                y_pred = (y_pred_proba >= optimal_threshold).astype(int)

                # 计算混淆矩阵
                conf_matrix = confusion_matrix(y_test, y_pred)
                tn, fp, fn, tp = conf_matrix.ravel()

                # 计算其他指标
                precision = precision_score(y_test, y_pred)
                recall = recall_score(y_test, y_pred)  # 即TPR
                specificity = tn / (tn + fp)  # 特异度
                f1 = f1_score(y_test, y_pred)
                auc_score = roc_auc_score(y_test, y_pred_proba)
                accuracy = accuracy_score(y_test, y_pred)

                # 计算阳性预测值和阴性预测值
                ppv = tp / (tp + fp) if (tp + fp) > 0 else 0  # 阳性预测值
                npv = tn / (tn + fn) if (tn + fn) > 0 else 0  # 阴性预测值

                # 打印评估结果
                print(f"{name} 评估结果 (at {actual_tpr:.2%} TPR, threshold={optimal_threshold:.4f}):")
                print(f"AUC: {auc_score:.4f}")
                print(f"Accuracy: {accuracy:.4f}")
                print(f"TPR (Recall/Sensitivity): {actual_tpr:.4f}")
                print(f"FPR: {actual_fpr:.4f}")
                print(f"TNR (Specificity): {specificity:.4f}")
                print(f"Precision (PPV): {ppv:.4f}")
                print(f"NPV: {npv:.4f}")
                print(f"F1 Score: {f1:.4f}")
                print("Confusion Matrix:")
                print(conf_matrix)
                print(f"TN: {tn}, FP: {fp}, FN: {fn}, TP: {tp}")
                print(classification_report(y_test, y_pred))

                # 保存模型和详细评估指标
                self.models['binary'][name] = {
                    'model': model,
                    'threshold': optimal_threshold,
                    'confusion_matrix': conf_matrix,
                    'tn': tn,
                    'fp': fp,
                    'fn': fn,
                    'tp': tp,
                    'tpr': actual_tpr,
                    'fpr': actual_fpr,
                    'specificity': specificity,
                    'precision': precision,
                    'recall': recall,
                    'f1': f1,
                    'auc': auc_score,
                    'accuracy': accuracy,
                    'ppv': ppv,
                    'npv': npv,
                    'predictions': y_pred,
                    'probabilities': y_pred_proba,
                    'roc_curve': {
                        'fpr': fpr,
                        'tpr': tpr,
                        'thresholds': thresholds
                    }
                }

            except Exception as e:
                print(f"Error training {name}: {e}")

    def _train_multiclass_models(self, X_train, y_train, X_test, y_test, y_test_binary):
        """
        训练多分类模型 - 内存优化版本
        """
        print("\n=== Training Multi-class Classification Models ===")

        models = {
            'XGBoost_Multi': xgb.XGBClassifier(
                n_estimators=100,
                max_depth=6,
                learning_rate=0.1,
                random_state=42,
                eval_metric='mlogloss'
            )
        }

        if 'multiclass' not in self.models:
            self.models['multiclass'] = {}

        for name, model in models.items():
            print(f"\nTraining {name}...")

            try:
                model.fit(X_train, y_train)

                # 预测
                y_pred = model.predict(X_test)
                y_pred_proba = model.predict_proba(X_test)

                # 多分类准确率
                accuracy = (y_pred == y_test).mean()

                # 欺诈检测准确率（不考虑具体类型）
                le = self.encoders['laundering_type']
                fraud_types = [i for i, label in enumerate(le.classes_) if not label.startswith('Normal')]

                y_pred_binary = np.isin(y_pred, fraud_types).astype(int)
                fraud_detection_accuracy = (y_pred_binary == y_test_binary).mean()
                fraud_auc = roc_auc_score(y_test_binary, np.max(y_pred_proba[:, fraud_types], axis=1) if len(
                    fraud_types) > 0 else y_pred_binary)

                print(f"{name} Multi-class Accuracy: {accuracy:.8f}")
                print(f"{name} Fraud Detection Accuracy: {fraud_detection_accuracy:.8f}")
                print(f"{name} Fraud Detection AUC: {fraud_auc:.8f}")

                # 保存模型和结果
                self.models['multiclass'][name] = {
                    'model': model,
                    'accuracy': accuracy,
                    'fraud_detection_accuracy': fraud_detection_accuracy,
                    'fraud_auc': fraud_auc,
                    'predictions': y_pred,
                    'probabilities': y_pred_proba,
                    'true_labels': y_test,
                    'class_names': le.classes_
                }

            except Exception as e:
                print(f"Error training {name}: {e}")

    def evaluate_models(self):
        """
        评估模型性能
        """
        print("\n=== Model Evaluation ===")

        try:
            # 创建评估图表目录
            os.makedirs('evaluation_plots', exist_ok=True)
            os.makedirs('enhanced_evaluation', exist_ok=True)
            print("Created directories: evaluation_plots, enhanced_evaluation")

            # 评估二分类模型（）
            self._evaluate_binary_models()

            print(
                "Model evaluation completed. ")

        except Exception as e:
            print(f"Error in model evaluation: {e}")
            import traceback
            traceback.print_exc()

    def _evaluate_binary_models(self):
        """
        评估二分类模型
        """
        if 'binary' not in self.models or not self.models['binary']:
            print("No binary models to evaluate")
            return

        print("Evaluating binary models...")

        try:
            y_test = self.test_df['Is_laundering']

            # ROC曲线
            plt.figure(figsize=(12, 8))

            for name, model_info in self.models['binary'].items():
                try:
                    y_pred_proba = model_info['probabilities']
                    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
                    auc_score = model_info['auc']
                    plt.plot(fpr, tpr, label=f'{name} (AUC = {auc_score:.3f})')
                except Exception as e:
                    print(f"Error plotting ROC for {name}: {e}")

            plt.plot([0, 1], [0, 1], 'k--', label='Random')
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title('ROC Curves - Binary Classification')
            plt.legend()
            plt.grid(True)
            plt.savefig('evaluation_plots/binary_roc_curves.png', dpi=300, bbox_inches='tight')
            plt.close()
            print("Binary ROC curves saved")

            # 混淆矩阵（）
            n_models = len(self.models['binary'])
            cols = min(2, n_models)
            rows = (n_models + 1) // 2

            fig, axes = plt.subplots(rows, cols, figsize=(15, 6 * rows))
            if n_models == 1:
                axes = [axes]
            elif rows == 1:
                axes = axes if isinstance(axes, (list, np.ndarray)) else [axes]
            else:
                axes = axes.flatten()

            for i, (name, model_info) in enumerate(self.models['binary'].items()):
                if i >= len(axes):
                    break

                try:
                    y_pred = model_info['predictions']
                    cm = confusion_matrix(y_test, y_pred)

                    # 使用matplotlib的imshow而不是seaborn
                    im = axes[i].imshow(cm, interpolation='nearest', cmap='Blues')
                    axes[i].figure.colorbar(im, ax=axes[i])

                    # 添加文本注释
                    thresh = cm.max() / 2.
                    for row in range(cm.shape[0]):
                        for col in range(cm.shape[1]):
                            axes[i].text(col, row, format(cm[row, col], 'd'),
                                         ha="center", va="center",
                                         color="white" if cm[row, col] > thresh else "black")

                    axes[i].set_title(f'{name} Confusion Matrix')
                    axes[i].set_xlabel('Predicted')
                    axes[i].set_ylabel('Actual')
                    axes[i].set_xticks([0, 1])
                    axes[i].set_yticks([0, 1])
                    axes[i].set_xticklabels(['Normal', 'Fraud'])
                    axes[i].set_yticklabels(['Normal', 'Fraud'])

                except Exception as e:
                    print(f"Error plotting confusion matrix for {name}: {e}")

            # 隐藏多余的子图
            for i in range(n_models, len(axes)):
                axes[i].set_visible(False)

            plt.tight_layout()
            plt.savefig('evaluation_plots/binary_confusion_matrices.png', dpi=300, bbox_inches='tight')
            plt.close()
            print("Binary confusion matrices saved")

        except Exception as e:
            print(f"Error in binary model evaluation: {e}")
            import traceback
            traceback.print_exc()

    def set_feature_names(self, feature_names):
        """设置特征名称"""
        self.feature_names = feature_names


    def save_models(self, path: str = "models"):
        """
        保存训练好的模型
        """
        print(f"Saving models to {path}...")

        os.makedirs(path, exist_ok=True)

        try:
            # 保存模型
            for model_type, models in self.models.items():
                for name, model_info in models.items():
                    model_path = os.path.join(path, f"{model_type}_{name}.joblib")
                    joblib.dump(model_info['model'], model_path)

            # 保存编码器和缩放器
            joblib.dump(self.encoders, os.path.join(path, "encoders.joblib"))
            joblib.dump(self.scalers, os.path.join(path, "scalers.joblib"))

            # 保存特征列表
            with open(os.path.join(path, "feature_columns.json"), 'w') as f:
                json.dump(self.feature_columns, f)

            print("Models saved successfully!")

        except Exception as e:
            print(f"Error saving models: {e}")

    def load_models(self, path: str = "models"):
        """
        加载训练好的模型
        """
        print(f"Loading models from {path}...")

        try:
            # 加载编码器和缩放器
            self.encoders = joblib.load(os.path.join(path, "encoders.joblib"))
            self.scalers = joblib.load(os.path.join(path, "scalers.joblib"))

            # 加载特征列表
            with open(os.path.join(path, "feature_columns.json"), 'r') as f:
                self.feature_columns = json.load(f)

            # 加载模型
            self.models = {'binary': {}, 'multiclass': {}}

            for file in os.listdir(path):
                if file.endswith('.joblib') and file not in ['encoders.joblib', 'scalers.joblib']:
                    model_type, name = file.replace('.joblib', '').split('_', 1)
                    model = joblib.load(os.path.join(path, file))
                    self.models[model_type][name] = {'model': model}

            print("Models loaded successfully!")

        except Exception as e:
            print(f"Error loading models: {e}")

    def predict(self, data: pd.DataFrame, model_name: str = 'XGBoost') -> Dict:
        """
        使用训练好的模型进行预测
        """
        print(f"Making predictions with {model_name}...")

        data_processed = data.copy()

        # 基础特征
        data_processed['Amount_log'] = np.log1p(data_processed['Amount'])
        data_processed['Is_cross_border'] = (
                    data_processed['Sender_bank_location'] != data_processed['Receiver_bank_location']).astype(int)
        data_processed['Currency_mismatch'] = (
                    data_processed['Payment_currency'] != data_processed['Received_currency']).astype(int)

        # 时间特征
        data_processed['Date'] = pd.to_datetime(data_processed['Date'])
        data_processed['Hour'] = pd.to_datetime(data_processed['Time'], format='%H:%M:%S').dt.hour
        data_processed['DayOfWeek'] = data_processed['Date'].dt.dayofweek
        data_processed['Is_weekend'] = (data_processed['DayOfWeek'] >= 5).astype(int)

        # 选择可用特征
        available_features = [col for col in self.feature_columns if col in data_processed.columns]
        X = data_processed[available_features]

        # 处理缺失值
        for col in available_features:
            if X[col].dtype in ['object', 'category']:
                X[col] = X[col].fillna('unknown')
            else:
                X[col] = X[col].fillna(X[col].median())

        # 特征缩放
        if 'standard' in self.scalers:
            X_scaled = self.scalers['standard'].transform(X)
        else:
            X_scaled = X

        results = {}

        # 二分类预测
        if 'binary' in self.models and model_name in self.models['binary']:
            model = self.models['binary'][model_name]['model']
            binary_pred = model.predict(X_scaled)
            binary_proba = model.predict_proba(X_scaled)[:, 1]

            results['is_laundering_prediction'] = binary_pred
            results['is_laundering_probability'] = binary_proba

        # 多分类预测
        if 'multiclass' in self.models and f'{model_name}_Multi' in self.models['multiclass']:
            model = self.models['multiclass'][f'{model_name}_Multi']['model']
            multi_pred = model.predict(X_scaled)
            multi_proba = model.predict_proba(X_scaled)

            # 解码预测结果
            le = self.encoders['laundering_type']
            type_pred = le.inverse_transform(multi_pred)

            results['laundering_type_prediction'] = type_pred
            results['laundering_type_probabilities'] = multi_proba

        return results



    def run_full_pipeline(self, data_path: str = None, sample_ratio: float = 1.0,
                          force_recreate_features: bool = False, feature_mode: str = 'full'):
        """
        运行完整的流水线
        
        Parameters:
        -----------
        data_path : str, optional
            数据文件路径，如果指定则重新检测数据集类型
        sample_ratio : float
            数据采样比例，默认1.0使用全部数据
        force_recreate_features : bool
            是否强制重新创建特征，默认False
        feature_mode : str
            特征创建模式，可选：
            - 'basic': 基础模式，不包含高级图特征（运行更快）
            - 'full': 完整模式，包含所有特征（默认）
            - 'custom': 自定义模式，使用self.feature_config配置
        """
        print("=== Starting Fraud Detection System Pipeline ===")

        # 1. 加载数据
        if data_path:
            self.data_path = data_path
            # 重新检测数据集类型
            self._detect_dataset_type()
            
        self.load_data(sample_ratio=sample_ratio, force_recreate_features=force_recreate_features, feature_mode=feature_mode)

        # 2. 划分数据
        self.split_data_by_month(train_ratio= 0.7)

        # 3. 训练模型
        self.train_models()

        # 4. 评估模型
        self.evaluate_models()

        # 5. 保存模型
        self.save_models()

        print("=== Pipeline completed successfully! ===")

    def set_feature_config(self, config: dict):
        """
        设置自定义特征配置
        
        Parameters:
        config: dict
            特征配置字典，键为特征类型，值为布尔值
            可用的特征类型：
            - 'basic': 基础特征
            - 'enhanced_activity': 增强活动特征（滑动窗口）
            - 'advanced_graph': 高级图特征（包含在滑动窗口中）
            - 'temporal': 时间模式特征
            - 'transaction_pattern': 交易模式特征
            - 'risk_score': 风险评分特征
            - 'advanced_graph_non_window': 非滑动窗口的高级图特征
            - 'time_series': 时间序列特征
            - 'behavioral_change': 行为变化特征
            - 'currency_cross_border': 多币种和跨境特征
        """
        # 更新配置，保留未指定的配置项
        for key, value in config.items():
            if key in self.feature_config:
                self.feature_config[key] = value
            else:
                print(f"Warning: Unknown feature type '{key}' ignored")
        
        print(f"Feature configuration updated: {self.feature_config}")

    def get_preset_configs(self):
        """
        获取预设的特征配置
        
        Returns:
        dict: 包含不同预设配置的字典
        """
        return {
            'minimal': {
                'basic': True,
                'enhanced_activity': True,
                'advanced_graph': False,
                'temporal': False,
                'transaction_pattern': True,
                'risk_score': False,
                'advanced_graph_non_window': False,
                'time_series': False,
                'behavioral_change': False,
                'currency_cross_border': True
            },
            'standard': {
                'basic': True,
                'enhanced_activity': True,
                'advanced_graph': False,
                'temporal': True,
                'transaction_pattern': True,
                'risk_score': True,
                'advanced_graph_non_window': False,
                'time_series': True,
                'behavioral_change': True,
                'currency_cross_border': True
            },
            'full_no_graph': {
                'basic': True,
                'enhanced_activity': True,
                'advanced_graph': False,
                'temporal': True,
                'transaction_pattern': True,
                'risk_score': True,
                'advanced_graph_non_window': False,
                'time_series': True,
                'behavioral_change': True,
                'currency_cross_border': True
            },
            'full': {
                'basic': True,
                'enhanced_activity': True,
                'advanced_graph': True,
                'temporal': True,
                'transaction_pattern': True,
                'risk_score': True,
                'advanced_graph_non_window': True,
                'time_series': True,
                'behavioral_change': True,
                'currency_cross_border': True
            }
        }

    def apply_preset_config(self, preset_name: str):
        """
        应用预设的特征配置
        
        Parameters:
        preset_name: str
            预设配置名称，可选：'minimal', 'standard', 'full_no_graph', 'full'
        """
        presets = self.get_preset_configs()
        if preset_name in presets:
            self.feature_config = presets[preset_name].copy()
            print(f"Applied preset configuration '{preset_name}': {self.feature_config}")
        else:
            available_presets = list(presets.keys())
            print(f"Error: Unknown preset '{preset_name}'. Available presets: {available_presets}")

import os

if __name__ == "__main__":
    print("Detected dataset files / 检测到的数据集文件：")
    available_datasets = []
    file_paths = {}  # Dictionary to store the full path of each file

    # Check multiple locations for dataset files
    # 在多个位置检查数据集文件
    search_locations = [
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),  # Parent directory / 上级目录
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data"),  # Parent's data / 上级的data目录
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "dataset"),
        # Parent's dataset / 上级的dataset目录
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "datasets"),
        # Parent's datasets / 上级的datasets目录
        os.path.dirname(os.path.abspath(__file__)),  # Current directory / 当前目录
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"),  # Current's data / 当前的data目录
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset"),  # Current's dataset / 当前的dataset目录
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "datasets"),  # Current's datasets / 当前的datasets目录
    ]

    # Target files to look for
    # 要查找的目标文件
    target_files = ["HI-Small_Trans.csv", "SAML-D.csv", "IBM_cache.csv", "features_cache.csv"]

    # Search for target files in all locations
    # 在所有位置搜索目标文件
    for location in search_locations:
        if os.path.exists(location):
            for file in target_files:
                file_path = os.path.join(location, file)
                if os.path.exists(file_path):
                    # Only add if the file hasn't been found yet or if we're in the current directory (priority)
                    # 仅当文件尚未找到或我们在当前目录（优先级）中时才添加
                    if file not in file_paths or location == os.path.dirname(os.path.abspath(__file__)):
                        file_paths[file] = file_path

    # Add found datasets to the available_datasets list
    # 将找到的数据集添加到可用数据集列表中
    index = 1
    if "HI-Small_Trans.csv" in file_paths:
        available_datasets.append("HI-Small_Trans.csv")
        print(f"{index}. HI-Small_Trans.csv (IBM format, supports binary classification / IBM格式，支持二分类)")
        print(f"   Location / 位置: {file_paths['HI-Small_Trans.csv']}")
        index += 1

    if "SAML-D.csv" in file_paths:
        available_datasets.append("SAML-D.csv")
        print(
            f"{index}. SAML-D.csv (SAML format, supports binary and multi-class classification / SAML格式，支持二分类和多分类)")
        print(f"   Location / 位置: {file_paths['SAML-D.csv']}")
        index += 1

    # Check for cache files
    # 检查缓存文件
    cache_files = []
    for cache_file in ["IBM_cache.csv", "features_cache.csv"]:
        if cache_file in file_paths:
            cache_files.append(cache_file)
            print(f"{index}. {cache_file} (Cache file / 缓存文件)")
            print(f"   Location / 位置: {file_paths[cache_file]}")
            index += 1

    # Combine all available files
    # 合并所有可用文件
    all_available_files = available_datasets + cache_files

    if not all_available_files:
        print("  No dataset files found / 未找到任何数据集文件")
        print("  Please ensure one of the following files exists: / 请确保以下文件之一存在：")
        print("    - HI-Small_Trans.csv")
        print("    - SAML-D.csv")
        print("    - IBM_cache.csv")
        print("    - features_cache.csv")
        print("  Or choose to load a custom CSV file / 或选择加载自定义CSV文件")

    # Add option to load other CSV files
    # 添加加载其他CSV文件的选项
    custom_file_option = len(all_available_files) + 1
    print(f"{custom_file_option}. Load other CSV file... / 加载其他CSV文件...")

    # User manual selection
    # 用户手动选择
    while True:
        try:
            choice = int(input(
                "\nPlease select a dataset to use [Enter the corresponding number]: / 请选择要使用的数据集 [输入对应数字]: "))

            if 1 <= choice <= len(all_available_files):
                selected_file = all_available_files[choice - 1]
                selected_data = file_paths[selected_file]
                print(f"Selected / 已选择: {selected_file}")
                print(f"Path / 路径: {selected_data}")
                break
            elif choice == custom_file_option:
                custom_path = input("Please enter the full path of the CSV file: / 请输入CSV文件的完整路径: ").strip()
                if os.path.exists(custom_path) and custom_path.lower().endswith('.csv'):
                    selected_data = custom_path
                    print(f"Selected custom file / 已选择自定义文件: {selected_data}")
                    break
                else:
                    print(
                        "Error: File does not exist or is not a CSV file, please select again / 错误: 文件不存在或不是CSV文件，请重新选择")
            else:
                print(
                    f"Error: Please enter a number between 1 and {custom_file_option} / 错误: 请输入1到{custom_file_option}之间的数字")
        except ValueError:
            print("Error: Please enter a valid number / 错误: 请输入有效的数字")

    # Initialize system
    # 初始化系统
    fraud_system = FraudDetectionSystem(data_path=selected_data)

    # Feature mode selection
    # 特征模式选择
    print(
        "\n=== Feature engineering mode selection, will use cache files if available / 特征工程模式选择，如有对应缓存文件则直接读取缓存 ===")
    print("1. basic - Basic mode (excludes advanced graph features, runs faster / 基础模式（不包含高级图特征，运行更快）)")
    print(
        "2. full - Full mode (includes all features, including advanced graph features / 完整模式（包含所有特征，包括高级图特征）)")
    print("3. custom - Custom mode (use preset configurations / 自定义模式（使用预设配置）)")
    print("4. default - Use default configuration (full mode / 使用默认配置（完整模式）)")

    while True:
        try:
            feature_choice = input(
                "\nPlease select feature mode [Enter 1-4, default is 4]: / 请选择特征模式 [输入1-4，默认4]: ").strip()
            if not feature_choice:
                feature_choice = '4'

            feature_choice = int(feature_choice)

            if feature_choice == 1:
                feature_mode = 'basic'
                print("Basic mode selected / 已选择基础模式")
                break
            elif feature_choice == 2:
                feature_mode = 'full'
                print("Full mode selected / 已选择完整模式")
                break
            elif feature_choice == 3:
                # Display preset configuration options
                # 显示预设配置选项
                presets = fraud_system.get_preset_configs()
                print("\nAvailable preset configurations / 可用的预设配置：")
                preset_list = list(presets.keys())
                for i, preset in enumerate(preset_list, 1):
                    print(f"  {i}. {preset}")

                preset_choice = input(
                    "Please select a preset configuration [Enter number]: / 请选择预设配置 [输入数字]: ").strip()
                try:
                    preset_idx = int(preset_choice) - 1
                    if 0 <= preset_idx < len(preset_list):
                        selected_preset = preset_list[preset_idx]
                        fraud_system.apply_preset_config(selected_preset)
                        feature_mode = 'custom'
                        print(f"Preset configuration selected / 已选择预设配置：{selected_preset}")
                        break
                    else:
                        print("Error: Please enter a valid number / 错误：请输入有效的数字")
                except ValueError:
                    print("Error: Please enter a number / 错误：请输入数字")
            elif feature_choice == 4:
                feature_mode = 'full'
                print("Using default configuration (full mode) / 使用默认配置（完整模式）")
                break
            else:
                print("Error: Please enter a number between 1 and 4 / 错误：请输入1-4之间的数字")
        except ValueError:
            print("Error: Please enter a valid number / 错误：请输入有效的数字")

    # Run the full pipeline
    # 运行完整流水线
    fraud_system.run_full_pipeline(
        sample_ratio=1.0,  # Use all data / 使用全部数据
        force_recreate_features=False,
        feature_mode=feature_mode
    )


